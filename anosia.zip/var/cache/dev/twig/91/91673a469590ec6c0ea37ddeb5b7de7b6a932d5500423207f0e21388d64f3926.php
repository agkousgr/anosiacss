<?php

/* products/modules/product_view_tabs.html.twig */
class __TwigTemplate_daa9d885459e4aceba9c14da928f67f333e7b09541c1fbebb925133693397411 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/product_view_tabs.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/product_view_tabs.html.twig"));

        // line 1
        echo "<div class=\"row single-product-details\">
    <div class=\"col-sm-12\">
        <!-- Nav tabs -->
        <ul class=\"nav nav-tabs\" role=\"tablist\">
            <li role=\"presentation\" class=\"active\"><a href=\"#Description\" aria-controls=\"Description\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-info-circle\"></i>Περιγραφή</a></li>
            <li role=\"presentation\"><a href=\"#Information\" aria-controls=\"Information\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-file-text-o\"></i>Συμπτωματολογία</a></li>
            ";
        // line 8
        echo "            ";
        // line 9
        echo "        </ul>

        <!-- Tab panes -->
        <div class=\"tab-content\">
            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"Description\">
                ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 14, $this->source); })()), "body", array()), "html", null, true);
        echo "
            </div>
            <div role=\"tabpanel\" class=\"tab-pane\" id=\"Information\">
                ";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 17, $this->source); })()), "extraInfo", array()), "html", null, true);
        echo "
            </div>
            ";
        // line 20
        echo "            ";
        // line 21
        echo "        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "products/modules/product_view_tabs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 21,  57 => 20,  52 => 17,  46 => 14,  39 => 9,  37 => 8,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"row single-product-details\">
    <div class=\"col-sm-12\">
        <!-- Nav tabs -->
        <ul class=\"nav nav-tabs\" role=\"tablist\">
            <li role=\"presentation\" class=\"active\"><a href=\"#Description\" aria-controls=\"Description\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-info-circle\"></i>Περιγραφή</a></li>
            <li role=\"presentation\"><a href=\"#Information\" aria-controls=\"Information\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-file-text-o\"></i>Συμπτωματολογία</a></li>
            {#<li role=\"presentation\"><a href=\"#Sizing\" aria-controls=\"Sizing\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-align-center\"></i>Sizing Guide</a></li>#}
            {#<li role=\"presentation\"><a href=\"#Reviews\" aria-controls=\"Reviews\" role=\"tab\" data-toggle=\"tab\"><i class=\"fa fa-comments\"></i>Reviews (0)</a></li>#}
        </ul>

        <!-- Tab panes -->
        <div class=\"tab-content\">
            <div role=\"tabpanel\" class=\"tab-pane active\" id=\"Description\">
                {{ pr.body }}
            </div>
            <div role=\"tabpanel\" class=\"tab-pane\" id=\"Information\">
                {{ pr.extraInfo }}
            </div>
            {#<div role=\"tabpanel\" class=\"tab-pane\" id=\"Sizing\">Sizing Guide</div>#}
            {#<div role=\"tabpanel\" class=\"tab-pane\" id=\"Reviews\">Reviews</div>#}
        </div>
    </div>
</div>", "products/modules/product_view_tabs.html.twig", "/var/www/html/anosia/templates/products/modules/product_view_tabs.html.twig");
    }
}
