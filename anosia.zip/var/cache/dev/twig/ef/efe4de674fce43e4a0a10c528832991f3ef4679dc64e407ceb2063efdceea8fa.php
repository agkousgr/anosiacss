<?php

/* orders/cart.html.twig */
class __TwigTemplate_bdd1d0f0485a115bd1b2a3a99953e9a217a78a1bb6eaa4c5fb170a87c7c1bd51 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "orders/cart.html.twig", 1);
        $this->blocks = array(
            'bodyId' => array($this, 'block_bodyId'),
            'title' => array($this, 'block_title'),
            'slider' => array($this, 'block_slider'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'breadcrumb' => array($this, 'block_breadcrumb'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "orders/cart.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "orders/cart.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_bodyId($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyId"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyId"));

        echo "cart";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " | Καλάθι";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_slider($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "slider"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "slider"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/css/orders.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_breadcrumb($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "breadcrumb"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 11
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "    ";
        $this->loadTemplate("partials/sidebar_login.html.twig", "orders/cart.html.twig", 15)->display($context);
        // line 16
        echo "    ";
        $this->loadTemplate("partials/swipe_menu.html.twig", "orders/cart.html.twig", 16)->display($context);
        // line 17
        echo "    ";
        $this->loadTemplate("partials/site_header.html.twig", "orders/cart.html.twig", 17)->display($context);
        // line 18
        echo "    <div class=\"page-header\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\"><h1>Καλάθι</h1></div>
            </div>
        </div>
    </div>
    <div class=\"section\" style=\"background-image:url(";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/bg-5.jpg"), "html", null, true);
        echo ");\">
        <div class=\"container\">
            <div class=\"col-xs-12\">
                ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 28, $this->source); })()), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 29
            echo "                    <div class=\"flash-notice\">
                        ";
            // line 30
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 33, $this->source); })()), "flashes", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 34
            echo "                    <div class=\"flash-success\">
                        ";
            // line 35
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "            </div>
            <section id=\"main\">
                <div class=\"cart-grid row\">
                    <!-- Left Block: cart product informations & shpping -->
                    <div class=\"cart-grid-body col-xs-12 col-lg-8\">

                        <!-- cart products detailed -->
                        <div class=\"card cart-container\">
                            <div class=\"card-block\">
                                <h1 class=\"h1\">Καλάθι αγορών</h1>
                            </div>
                            <hr class=\"separator\">
                            ";
        // line 50
        if ((twig_length_filter($this->env, (isset($context["cartItems"]) || array_key_exists("cartItems", $context) ? $context["cartItems"] : (function () { throw new Twig_Error_Runtime('Variable "cartItems" does not exist.', 50, $this->source); })())) > 0)) {
            // line 51
            echo "                                <form name=\"cart-items\" action=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("update_cart");
            echo "\" method=\"post\">
                                    <div class=\"cart-overview js-cart\" data-refresh-url=\"\">

                                        <ul class=\"cart-items\">
                                            ";
            // line 55
            $context["cartSubTotal"] = 0;
            // line 56
            echo "                                            ";
            $context["cartTotal"] = 0;
            // line 57
            echo "                                            ";
            $context["cartShippingCost"] = 0;
            // line 58
            echo "                                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cartItems"]) || array_key_exists("cartItems", $context) ? $context["cartItems"] : (function () { throw new Twig_Error_Runtime('Variable "cartItems" does not exist.', 58, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
                // line 59
                echo "                                                <li class=\"cart-item\">
                                                    <div class=\"product-line-grid\">
                                                        <!--  product left content: image-->
                                                        <div class=\"product-line-grid-left col-md-3 col-xs-4\">
                                                            <span class=\"product-image media-middle\">
                                                                <img src=\"";
                // line 64
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
                echo "\"
                                                                     alt=\"voluptate velit esse\">
                                                            </span>
                                                        </div>

                                                        <!--  product left body: description -->
                                                        <div class=\"product-line-grid-body col-md-4 col-xs-8\">
                                                            <div class=\"product-line-info\">
                                                                <a class=\"\"
                                                                   href=\"";
                // line 73
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
                echo "</a>
                                                            </div>

                                                            <div class=\"product-line-info product-price h5 has-discount\">
                                                                ";
                // line 77
                if ((twig_get_attribute($this->env, $this->source, $context["pr"], "discount", array()) > 0)) {
                    // line 78
                    echo "                                                                    <div class=\"product-discount\">
                                                                        <span class=\"regular-price\">";
                    // line 79
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), 2, ",", "."), "html", null, true);
                    echo "€</span>
                                                                        <span class=\"discount discount-amount\">-";
                    // line 80
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "discount", array()), "html", null, true);
                    echo "%</span>
                                                                    </div>
                                                                ";
                }
                // line 83
                echo "                                                                <div class=\"current-price\">
                                                                    <span class=\"price\">";
                // line 84
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), 2, ",", "."), "html", null, true);
                echo "€</span>
                                                                </div>
                                                            </div>

                                                            ";
                // line 89
                echo "
                                                            ";
                // line 91
                echo "                                                            ";
                // line 92
                echo "                                                            ";
                // line 93
                echo "                                                            ";
                // line 94
                echo "
                                                        </div>

                                                        <!--  product left body: description -->
                                                        ";
                // line 98
                if ((twig_get_attribute($this->env, $this->source, $context["pr"], "maxByOrder", array()) > 0)) {
                    // line 99
                    echo "                                                            ";
                    $context["maxItems"] = twig_get_attribute($this->env, $this->source, $context["pr"], "maxByOrder", array());
                    // line 100
                    echo "                                                        ";
                } elseif ((twig_get_attribute($this->env, $this->source, $context["pr"], "webFree", array()) == "true")) {
                    // line 101
                    echo "                                                            ";
                    $context["maxItems"] = (twig_get_attribute($this->env, $this->source, $context["pr"], "remainNotReserved", array()) + twig_get_attribute($this->env, $this->source, $context["pr"], "overAvailability", array()));
                    // line 102
                    echo "                                                        ";
                } else {
                    // line 103
                    echo "                                                            ";
                    $context["maxItems"] = twig_get_attribute($this->env, $this->source, $context["pr"], "remainNotReserved", array());
                    // line 104
                    echo "                                                        ";
                }
                // line 105
                echo "                                                        <div class=\"product-line-grid-right product-line-actions col-md-5 col-xs-12\">
                                                            <div class=\"row\">
                                                                <div class=\"col-xs-4 hidden-md-up\"></div>
                                                                <div class=\"col-md-10 col-xs-6\">
                                                                    <div class=\"row\">
                                                                        <div class=\"col-md-8 col-xs-6\">
                                                                            <div class=\"form-group\">
                                                                                <input id=\"add-quantity\"
                                                                                       name=\"quantity[";
                // line 113
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "cartId", array()), "html", null, true);
                echo "]\"
                                                                                       class=\"form-control stepper\"
                                                                                       type=\"number\"
                                                                                       value=\"";
                // line 116
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "quantity", array()), "html", null, true);
                echo "\"
                                                                                       min=\"1\"
                                                                                       max=\"";
                // line 118
                echo twig_escape_filter($this->env, (isset($context["maxItems"]) || array_key_exists("maxItems", $context) ? $context["maxItems"] : (function () { throw new Twig_Error_Runtime('Variable "maxItems" does not exist.', 118, $this->source); })()), "html", null, true);
                echo "\"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class=\"col-md-4 col-xs-2 price\">
                                                                            <span class=\"product-price\">
                                                                                <strong>
                                                                                    ";
                // line 124
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), 2, ".", ",") * twig_get_attribute($this->env, $this->source, $context["pr"], "quantity", array())), 2, ",", "."), "html", null, true);
                echo "€
                                                                                </strong>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class=\"col-md-2 col-xs-2 text-xsright\">
                                                                    <div class=\"cart-line-product-actions\">
                                                                        <a class=\"remove-from-cart\"
                                                                           rel=\"nofollow\"
                                                                           href=\"";
                // line 134
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_cart_item", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "cartId", array()))), "html", null, true);
                echo "\">
                                                                            <i class=\"material-icons float-xs-left\">Delete</i>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class=\"clearfix\"></div>
                                                    </div>
                                                </li>
                                                <input type=\"hidden\" name=\"cart\" value=\"1\">
                                                ";
                // line 145
                $context["cartSubTotal"] = ((isset($context["cartSubTotal"]) || array_key_exists("cartSubTotal", $context) ? $context["cartSubTotal"] : (function () { throw new Twig_Error_Runtime('Variable "cartSubTotal" does not exist.', 145, $this->source); })()) + (twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), 2, ".", ",") * twig_get_attribute($this->env, $this->source, $context["pr"], "quantity", array())));
                // line 146
                echo "                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 147
            echo "
                                        </ul>
                                    </div>
                                    <div class=\"text-sm-center\" style=\"padding: 10px 0 20px;\">
                                        <a class=\"btn-primary\" id=\"update-cart-btn\" href=\"\">
                                            Ενημέρωση καλαθιού
                                        </a>
                                    </div>
                                </form>
                            ";
        } else {
            // line 157
            echo "                                <div class=\"col-xs-12 general-message\">Δεν υπάρχουν προϊόντα στο καλάθι σας!</div>
                            ";
        }
        // line 159
        echo "                        </div>
                        <a style=\"font-size:16px;\" class=\"\"
                           href=\"javascript:history.back()\">
                            <i class=\"fa fa-chevron-left\"></i> Συνεχίστε τα ψώνια σας
                        </a>
                        <!-- shipping informations -->
                    </div>

                    ";
        // line 167
        if ((twig_length_filter($this->env, (isset($context["cartItems"]) || array_key_exists("cartItems", $context) ? $context["cartItems"] : (function () { throw new Twig_Error_Runtime('Variable "cartItems" does not exist.', 167, $this->source); })())) > 0)) {
            // line 168
            echo "                        <!-- Right Block: cart subtotal & cart total -->
                        <div class=\"cart-grid-right col-xs-12 col-lg-4\">
                            <div class=\"card cart-summary\">
                                <div class=\"cart-detailed-totals\">
                                    <div class=\"card-block\">
                                        <div class=\"cart-summary-line\" id=\"cart-subtotal-products\">
                                            <span class=\"label js-subtotal\">
                                                ";
            // line 175
            echo twig_escape_filter($this->env, (isset($context["totalCartItems"]) || array_key_exists("totalCartItems", $context) ? $context["totalCartItems"] : (function () { throw new Twig_Error_Runtime('Variable "totalCartItems" does not exist.', 175, $this->source); })()), "html", null, true);
            echo "
                                                ";
            // line 176
            if (((isset($context["totalCartItems"]) || array_key_exists("totalCartItems", $context) ? $context["totalCartItems"] : (function () { throw new Twig_Error_Runtime('Variable "totalCartItems" does not exist.', 176, $this->source); })()) == 1)) {
                // line 177
                echo "                                                    προϊόν
                                                ";
            } else {
                // line 179
                echo "                                                    προϊόντα
                                                ";
            }
            // line 181
            echo "                                            </span>
                                            <span class=\"value\">";
            // line 182
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["cartSubTotal"]) || array_key_exists("cartSubTotal", $context) ? $context["cartSubTotal"] : (function () { throw new Twig_Error_Runtime('Variable "cartSubTotal" does not exist.', 182, $this->source); })()), 2, ",", "."), "html", null, true);
            echo "
                                                €</span>
                                        </div>
                                        <div class=\"cart-summary-line\" id=\"cart-subtotal-shipping\">
                                            <span class=\"label\">
                                                Μεταφορικά
                                            </span>
                                            <span class=\"value\">Δωρεάν</span>
                                            <div>
                                                <small class=\"value\"></small>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class=\"separator\">
                                    <div class=\"card-block\">
                                        ";
            // line 197
            $context["cartTotal"] = ((isset($context["cartSubTotal"]) || array_key_exists("cartSubTotal", $context) ? $context["cartSubTotal"] : (function () { throw new Twig_Error_Runtime('Variable "cartSubTotal" does not exist.', 197, $this->source); })()) + (isset($context["cartShippingCost"]) || array_key_exists("cartShippingCost", $context) ? $context["cartShippingCost"] : (function () { throw new Twig_Error_Runtime('Variable "cartShippingCost" does not exist.', 197, $this->source); })()));
            // line 198
            echo "                                        <div class=\"cart-summary-line cart-total\">
                                            <span class=\"label\">Σύνολο (με ΦΠΑ)</span>
                                            <span class=\"value\">";
            // line 200
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["cartTotal"]) || array_key_exists("cartTotal", $context) ? $context["cartTotal"] : (function () { throw new Twig_Error_Runtime('Variable "cartTotal" does not exist.', 200, $this->source); })()), 2, ",", "."), "html", null, true);
            echo "
                                                €</span>
                                        </div>

                                    </div>
                                </div>
                                <div class=\"checkout cart-detailed-actions card-block\">
                                    <div class=\"text-sm-center\">
                                        <a href=\"";
            // line 208
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("checkout");
            echo "\" class=\"btn btn-primary\">Ταμείο</a>

                                    </div>
                                </div>
                            </div>
                            <div id=\"block-reassurance\">
                                <ul>
                                    <li>
                                        <div class=\"block-reassurance-item\">
                                            <img src=\"https://demo.templatetrip.com/Prestashop/PRS06/PRS176_gym/modules/blockreassurance/img/ic_verified_user_black_36dp_1x.png\"
                                                 alt=\"Security policy (edit with Customer reassurance module)\">
                                            <span class=\"h6\">Security policy (edit with Customer reassurance
                                                module)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"block-reassurance-item\">
                                            <img src=\"https://demo.templatetrip.com/Prestashop/PRS06/PRS176_gym/modules/blockreassurance/img/ic_local_shipping_black_36dp_1x.png\"
                                                 alt=\"Delivery policy (edit with Customer reassurance module)\">
                                            <span class=\"h6\">Delivery policy (edit with Customer reassurance
                                                module)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"block-reassurance-item\">
                                            <img src=\"https://demo.templatetrip.com/Prestashop/PRS06/PRS176_gym/modules/blockreassurance/img/ic_swap_horiz_black_36dp_1x.png\"
                                                 alt=\"Return policy (edit with Customer reassurance module)\">
                                            <span class=\"h6\">Return policy (edit with Customer reassurance
                                                module)</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    ";
        }
        // line 243
        echo "                </div>
            </section>
        </div>
        ";
        // line 246
        $this->loadTemplate("home_page_modules/14_newsletter.html.twig", "orders/cart.html.twig", 246)->display($context);
        // line 247
        echo "        ";
        $this->loadTemplate("home_page_modules/15_social.html.twig", "orders/cart.html.twig", 247)->display($context);
        // line 248
        echo "        ";
        $this->loadTemplate("partials/footer.html.twig", "orders/cart.html.twig", 248)->display($context);
        // line 249
        echo "    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 252
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 253
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 254
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/js/cart.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "orders/cart.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  570 => 254,  565 => 253,  556 => 252,  545 => 249,  542 => 248,  539 => 247,  537 => 246,  532 => 243,  494 => 208,  483 => 200,  479 => 198,  477 => 197,  459 => 182,  456 => 181,  452 => 179,  448 => 177,  446 => 176,  442 => 175,  433 => 168,  431 => 167,  421 => 159,  417 => 157,  405 => 147,  399 => 146,  397 => 145,  383 => 134,  370 => 124,  361 => 118,  356 => 116,  350 => 113,  340 => 105,  337 => 104,  334 => 103,  331 => 102,  328 => 101,  325 => 100,  322 => 99,  320 => 98,  314 => 94,  312 => 93,  310 => 92,  308 => 91,  305 => 89,  298 => 84,  295 => 83,  289 => 80,  285 => 79,  282 => 78,  280 => 77,  271 => 73,  259 => 64,  252 => 59,  247 => 58,  244 => 57,  241 => 56,  239 => 55,  231 => 51,  229 => 50,  215 => 38,  206 => 35,  203 => 34,  198 => 33,  189 => 30,  186 => 29,  182 => 28,  176 => 25,  167 => 18,  164 => 17,  161 => 16,  158 => 15,  149 => 14,  138 => 11,  129 => 10,  117 => 8,  112 => 7,  103 => 6,  86 => 5,  68 => 4,  50 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block bodyId %}cart{% endblock %}
{% block title %} | Καλάθι{% endblock %}
{% block slider %}{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link href=\"{{ asset('build/css/orders.css') }}\" rel=\"stylesheet\"/>
{% endblock %}
{% block breadcrumb %}

{% endblock %}

{% block body %}
    {% include 'partials/sidebar_login.html.twig' %}
    {% include 'partials/swipe_menu.html.twig' %}
    {% include 'partials/site_header.html.twig' %}
    <div class=\"page-header\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\"><h1>Καλάθι</h1></div>
            </div>
        </div>
    </div>
    <div class=\"section\" style=\"background-image:url({{ asset('images/bg-5.jpg') }});\">
        <div class=\"container\">
            <div class=\"col-xs-12\">
                {% for message in app.flashes('notice') %}
                    <div class=\"flash-notice\">
                        {{ message }}
                    </div>
                {% endfor %}
                {% for message in app.flashes('success') %}
                    <div class=\"flash-success\">
                        {{ message }}
                    </div>
                {% endfor %}
            </div>
            <section id=\"main\">
                <div class=\"cart-grid row\">
                    <!-- Left Block: cart product informations & shpping -->
                    <div class=\"cart-grid-body col-xs-12 col-lg-8\">

                        <!-- cart products detailed -->
                        <div class=\"card cart-container\">
                            <div class=\"card-block\">
                                <h1 class=\"h1\">Καλάθι αγορών</h1>
                            </div>
                            <hr class=\"separator\">
                            {% if cartItems|length > 0 %}
                                <form name=\"cart-items\" action=\"{{ path('update_cart') }}\" method=\"post\">
                                    <div class=\"cart-overview js-cart\" data-refresh-url=\"\">

                                        <ul class=\"cart-items\">
                                            {% set cartSubTotal = 0 %}
                                            {% set cartTotal = 0 %}
                                            {% set cartShippingCost = 0 %}
                                            {% for pr in cartItems %}
                                                <li class=\"cart-item\">
                                                    <div class=\"product-line-grid\">
                                                        <!--  product left content: image-->
                                                        <div class=\"product-line-grid-left col-md-3 col-xs-4\">
                                                            <span class=\"product-image media-middle\">
                                                                <img src=\"{{ pr.imageUrl }}\"
                                                                     alt=\"voluptate velit esse\">
                                                            </span>
                                                        </div>

                                                        <!--  product left body: description -->
                                                        <div class=\"product-line-grid-body col-md-4 col-xs-8\">
                                                            <div class=\"product-line-info\">
                                                                <a class=\"\"
                                                                   href=\"{{ path('product_view', {'id':pr.id}) }}\">{{ pr.name }}</a>
                                                            </div>

                                                            <div class=\"product-line-info product-price h5 has-discount\">
                                                                {% if pr.discount > 0 %}
                                                                    <div class=\"product-discount\">
                                                                        <span class=\"regular-price\">{{ pr.retailPrice|number_format(2, ',', '.') }}€</span>
                                                                        <span class=\"discount discount-amount\">-{{ pr.discount }}%</span>
                                                                    </div>
                                                                {% endif %}
                                                                <div class=\"current-price\">
                                                                    <span class=\"price\">{{ pr.webPrice|number_format(2, ',', '.') }}€</span>
                                                                </div>
                                                            </div>

                                                            {#<br>#}

                                                            {#<div class=\"product-line-info\">#}
                                                            {#<span class=\"label\">Dimension:</span>#}
                                                            {#<span class=\"value\">40x60cm</span>#}
                                                            {#</div>#}

                                                        </div>

                                                        <!--  product left body: description -->
                                                        {% if (pr.maxByOrder > 0) %}
                                                            {% set maxItems = pr.maxByOrder %}
                                                        {% elseif (pr.webFree == 'true') %}
                                                            {% set maxItems = pr.remainNotReserved + pr.overAvailability %}
                                                        {% else %}
                                                            {% set maxItems = pr.remainNotReserved %}
                                                        {% endif %}
                                                        <div class=\"product-line-grid-right product-line-actions col-md-5 col-xs-12\">
                                                            <div class=\"row\">
                                                                <div class=\"col-xs-4 hidden-md-up\"></div>
                                                                <div class=\"col-md-10 col-xs-6\">
                                                                    <div class=\"row\">
                                                                        <div class=\"col-md-8 col-xs-6\">
                                                                            <div class=\"form-group\">
                                                                                <input id=\"add-quantity\"
                                                                                       name=\"quantity[{{ pr.cartId }}]\"
                                                                                       class=\"form-control stepper\"
                                                                                       type=\"number\"
                                                                                       value=\"{{ pr.quantity }}\"
                                                                                       min=\"1\"
                                                                                       max=\"{{ maxItems }}\"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class=\"col-md-4 col-xs-2 price\">
                                                                            <span class=\"product-price\">
                                                                                <strong>
                                                                                    {{ ((pr.webPrice|number_format(2, '.', ','))*pr.quantity)|number_format(2, ',', '.') }}€
                                                                                </strong>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class=\"col-md-2 col-xs-2 text-xsright\">
                                                                    <div class=\"cart-line-product-actions\">
                                                                        <a class=\"remove-from-cart\"
                                                                           rel=\"nofollow\"
                                                                           href=\"{{ path('delete_cart_item', {'id':pr.cartId}) }}\">
                                                                            <i class=\"material-icons float-xs-left\">Delete</i>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class=\"clearfix\"></div>
                                                    </div>
                                                </li>
                                                <input type=\"hidden\" name=\"cart\" value=\"1\">
                                                {% set cartSubTotal = cartSubTotal + (pr.webPrice|number_format(2, '.', ','))*pr.quantity %}
                                            {% endfor %}

                                        </ul>
                                    </div>
                                    <div class=\"text-sm-center\" style=\"padding: 10px 0 20px;\">
                                        <a class=\"btn-primary\" id=\"update-cart-btn\" href=\"\">
                                            Ενημέρωση καλαθιού
                                        </a>
                                    </div>
                                </form>
                            {% else %}
                                <div class=\"col-xs-12 general-message\">Δεν υπάρχουν προϊόντα στο καλάθι σας!</div>
                            {% endif %}
                        </div>
                        <a style=\"font-size:16px;\" class=\"\"
                           href=\"javascript:history.back()\">
                            <i class=\"fa fa-chevron-left\"></i> Συνεχίστε τα ψώνια σας
                        </a>
                        <!-- shipping informations -->
                    </div>

                    {% if cartItems|length > 0 %}
                        <!-- Right Block: cart subtotal & cart total -->
                        <div class=\"cart-grid-right col-xs-12 col-lg-4\">
                            <div class=\"card cart-summary\">
                                <div class=\"cart-detailed-totals\">
                                    <div class=\"card-block\">
                                        <div class=\"cart-summary-line\" id=\"cart-subtotal-products\">
                                            <span class=\"label js-subtotal\">
                                                {{ totalCartItems }}
                                                {% if totalCartItems == 1 %}
                                                    προϊόν
                                                {% else %}
                                                    προϊόντα
                                                {% endif %}
                                            </span>
                                            <span class=\"value\">{{ cartSubTotal|number_format(2, ',', '.') }}
                                                €</span>
                                        </div>
                                        <div class=\"cart-summary-line\" id=\"cart-subtotal-shipping\">
                                            <span class=\"label\">
                                                Μεταφορικά
                                            </span>
                                            <span class=\"value\">Δωρεάν</span>
                                            <div>
                                                <small class=\"value\"></small>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class=\"separator\">
                                    <div class=\"card-block\">
                                        {% set cartTotal = cartSubTotal + cartShippingCost %}
                                        <div class=\"cart-summary-line cart-total\">
                                            <span class=\"label\">Σύνολο (με ΦΠΑ)</span>
                                            <span class=\"value\">{{ cartTotal|number_format(2, ',', '.') }}
                                                €</span>
                                        </div>

                                    </div>
                                </div>
                                <div class=\"checkout cart-detailed-actions card-block\">
                                    <div class=\"text-sm-center\">
                                        <a href=\"{{ path('checkout') }}\" class=\"btn btn-primary\">Ταμείο</a>

                                    </div>
                                </div>
                            </div>
                            <div id=\"block-reassurance\">
                                <ul>
                                    <li>
                                        <div class=\"block-reassurance-item\">
                                            <img src=\"https://demo.templatetrip.com/Prestashop/PRS06/PRS176_gym/modules/blockreassurance/img/ic_verified_user_black_36dp_1x.png\"
                                                 alt=\"Security policy (edit with Customer reassurance module)\">
                                            <span class=\"h6\">Security policy (edit with Customer reassurance
                                                module)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"block-reassurance-item\">
                                            <img src=\"https://demo.templatetrip.com/Prestashop/PRS06/PRS176_gym/modules/blockreassurance/img/ic_local_shipping_black_36dp_1x.png\"
                                                 alt=\"Delivery policy (edit with Customer reassurance module)\">
                                            <span class=\"h6\">Delivery policy (edit with Customer reassurance
                                                module)</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"block-reassurance-item\">
                                            <img src=\"https://demo.templatetrip.com/Prestashop/PRS06/PRS176_gym/modules/blockreassurance/img/ic_swap_horiz_black_36dp_1x.png\"
                                                 alt=\"Return policy (edit with Customer reassurance module)\">
                                            <span class=\"h6\">Return policy (edit with Customer reassurance
                                                module)</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    {% endif %}
                </div>
            </section>
        </div>
        {% include 'home_page_modules/14_newsletter.html.twig' %}
        {% include 'home_page_modules/15_social.html.twig' %}
        {% include 'partials/footer.html.twig' %}
    </div>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('build/js/cart.js') }}\"></script>
{% endblock %}", "orders/cart.html.twig", "/var/www/html/anosia/templates/orders/cart.html.twig");
    }
}
