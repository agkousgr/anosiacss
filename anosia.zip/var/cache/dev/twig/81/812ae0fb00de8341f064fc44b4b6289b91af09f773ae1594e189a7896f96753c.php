<?php

/* products/modules/top_categories.html.twig */
class __TwigTemplate_327b983da3bc7e907fde707832adf42d2c35770bf5e0266820757336d8ef2848 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/top_categories.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/top_categories.html.twig"));

        // line 1
        echo "<div class=\"section\" style=\"background-image:url(";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/bg-9.jpg"), "html", null, true);
        echo ");\">
    <div class=\"container\">
        <div class=\"category-scroller\">
            <h2>Επιλεξτε κατηγορια</h2>
            <div class=\"owl-carousel owl-theme CatCarousel\">
                ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) || array_key_exists("categories", $context) ? $context["categories"] : (function () { throw new Twig_Error_Runtime('Variable "categories" does not exist.', 6, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["ctg"]) {
            // line 7
            echo "                    ";
            if ((twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ctg"], "id", array())) == twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ctgInfo"]) || array_key_exists("ctgInfo", $context) ? $context["ctgInfo"] : (function () { throw new Twig_Error_Runtime('Variable "ctgInfo" does not exist.', 7, $this->source); })()), "id", array())))) {
                // line 8
                echo "                        ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["ctg"], "children", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["subctg"]) {
                    // line 9
                    echo "                            <div class=\"item  wow fadeIn\" data-wow-delay=\"0.4s\">
                                <div class=\"category-image\">
                                    <a href=\"";
                    // line 11
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list", array("id" => twig_get_attribute($this->env, $this->source, $context["subctg"], "id", array()))), "html", null, true);
                    echo "\">
                                        <p>";
                    // line 12
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subctg"], "name", array()), "html", null, true);
                    echo "</p>
                                        <img src=\"";
                    // line 13
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subctg"], "imageUrl", array()), "html", null, true);
                    echo "\" alt=\"\"></a>
                                </div>
                            </div>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subctg'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 17
                echo "                    ";
            }
            // line 18
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ctg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "            </div>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "products/modules/top_categories.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 19,  75 => 18,  72 => 17,  62 => 13,  58 => 12,  54 => 11,  50 => 9,  45 => 8,  42 => 7,  38 => 6,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"section\" style=\"background-image:url({{ asset('images/bg-9.jpg') }});\">
    <div class=\"container\">
        <div class=\"category-scroller\">
            <h2>Επιλεξτε κατηγορια</h2>
            <div class=\"owl-carousel owl-theme CatCarousel\">
                {% for ctg in categories %}
                    {% if ctg.id|number_format == ctgInfo.id|number_format %}
                        {% for subctg in ctg.children %}
                            <div class=\"item  wow fadeIn\" data-wow-delay=\"0.4s\">
                                <div class=\"category-image\">
                                    <a href=\"{{ path('products_list', {'id':subctg.id}) }}\">
                                        <p>{{ subctg.name }}</p>
                                        <img src=\"{{ subctg.imageUrl }}\" alt=\"\"></a>
                                </div>
                            </div>
                        {% endfor %}
                    {% endif %}
                {% endfor %}
            </div>
        </div>
    </div>
</div>", "products/modules/top_categories.html.twig", "/var/www/html/anosia/templates/products/modules/top_categories.html.twig");
    }
}
