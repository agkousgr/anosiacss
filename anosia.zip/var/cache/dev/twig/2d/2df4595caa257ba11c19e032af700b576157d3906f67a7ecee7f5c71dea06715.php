<?php

/* products/modules/bottom_product_tabs.html.twig */
class __TwigTemplate_512661e2919668609225fad29fec159bc9dff622ac3db9df6676c878b99081e7 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/bottom_product_tabs.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/bottom_product_tabs.html.twig"));

        // line 1
        echo "<div class=\"ProductTab\">
    <ul class=\"resp-tabs-list hor_1\">
        <li>ΑΝΔΡΑΣ</li>
        <li>ΓΥΝΑΙΚΑ</li>
        <li>ΠΑΙΔΙ</li>
    </ul>
    <div class=\"resp-tabs-container hor_1\">
        <div id=\"men_id\">
            <div class=\"owl-carousel owl-theme ProductScrollTab\">
                ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 10, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 11
            echo "                    <div class=\"item\">
                        <div class=\"product-case\">
                            <div class=\"tag tag-green\"><span>new</span></div>
                            <div class=\"product-img\">
                                <div class=\"hover-img\">
                                    <img src=\"";
            // line 16
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                </div>
                                <a href=\"#\"><img src=\"";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\"></a>
                            </div>
                            <div class=\"hover-info\">
                                <div class=\"product-short-info\">
                                    <div class=\"product-name\">
                                        <a href=\"#\">";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </div>
                                    ";
            // line 26
            echo "                                    ";
            // line 27
            echo "                                    ";
            // line 28
            echo "                                    ";
            // line 29
            echo "                                    <div class=\"product-price\">
                                        <div class=\"product-price-span\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                            <del>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                        </div>
                                    </div>
                                    <button type=\"button\"><i class=\"fa fa-cart-plus\"></i>
                                        <span>Καλάθι</span>
                                    </button>
                                </div>
                            </div>
                            <div class=\"product-short-info\">
                                <div class=\"product-name\">
                                    <a href=\"#\">";
            // line 41
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                </div>
                                ";
            // line 44
            echo "                                ";
            // line 45
            echo "                                ";
            // line 46
            echo "                                ";
            // line 47
            echo "                                ";
            // line 48
            echo "                                <div class=\"product-price\">
                                    <div class=\"product-price-span\">";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "            </div>
        </div>


        <div id=\"women_id\">
            <div class=\"owl-carousel owl-theme ProductScrollTab\">
                ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 63, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 64
            echo "                    <div class=\"item\">
                        <div class=\"product-case\">
                            <div class=\"tag tag-green\"><span>new</span></div>
                            <div class=\"product-img\">
                                <div class=\"hover-img\">
                                    <img src=\"images/product-1-h.jpg\" alt=\"";
            // line 69
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                </div>
                                <a href=\"#\"><img src=\"images/product-1.jpg\" alt=\"";
            // line 71
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\"></a>
                            </div>
                            <div class=\"hover-info\">
                                <div class=\"product-short-info\">
                                    <div class=\"product-name\">
                                        <a href=\"#\">";
            // line 76
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </div>
                                    ";
            // line 79
            echo "                                    ";
            // line 80
            echo "                                    ";
            // line 81
            echo "                                    ";
            // line 82
            echo "                                    <div class=\"product-price\">
                                        <div class=\"product-price-span\">";
            // line 83
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                            <del>";
            // line 84
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                        </div>
                                    </div>
                                    <button type=\"button\"><i class=\"fa fa-cart-plus\"></i>
                                        <span>Καλάθι</span>
                                    </button>
                                </div>
                            </div>
                            <div class=\"product-short-info\">
                                <div class=\"product-name\">
                                    <a href=\"#\">";
            // line 94
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                </div>
                                ";
            // line 97
            echo "                                ";
            // line 98
            echo "                                ";
            // line 99
            echo "                                ";
            // line 100
            echo "                                ";
            // line 101
            echo "                                <div class=\"product-price\">
                                    <div class=\"product-price-span\">";
            // line 102
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 103
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 110
        echo "            </div>
        </div>


        <div id=\"acce_id\">
            <div class=\"owl-carousel owl-theme ProductScrollTab\">
                ";
        // line 116
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 116, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 117
            echo "                    <div class=\"item\">
                        <div class=\"product-case\">
                            <div class=\"tag tag-green\"><span>new</span></div>
                            <div class=\"product-img\">
                                <div class=\"hover-img\">
                                    <img src=\"images/product-1-h.jpg\" alt=\"";
            // line 122
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                </div>
                                <a href=\"#\"><img src=\"images/product-1.jpg\" alt=\"";
            // line 124
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\"></a>
                            </div>
                            <div class=\"hover-info\">
                                <div class=\"product-short-info\">
                                    <div class=\"product-name\">
                                        <a href=\"#\">";
            // line 129
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </div>
                                    ";
            // line 132
            echo "                                    ";
            // line 133
            echo "                                    ";
            // line 134
            echo "                                    ";
            // line 135
            echo "                                    <div class=\"product-price\">
                                        <div class=\"product-price-span\">";
            // line 136
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                            <del>";
            // line 137
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                        </div>
                                    </div>
                                    <button type=\"button\"><i class=\"fa fa-cart-plus\"></i>
                                        <span>Καλάθι</span>
                                    </button>
                                </div>
                            </div>
                            <div class=\"product-short-info\">
                                <div class=\"product-name\">
                                    <a href=\"#\">";
            // line 147
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                </div>
                                ";
            // line 150
            echo "                                ";
            // line 151
            echo "                                ";
            // line 152
            echo "                                ";
            // line 153
            echo "                                ";
            // line 154
            echo "                                <div class=\"product-price\">
                                    <div class=\"product-price-span\">";
            // line 155
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 156
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 163
        echo "            </div>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "products/modules/bottom_product_tabs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  324 => 163,  311 => 156,  307 => 155,  304 => 154,  302 => 153,  300 => 152,  298 => 151,  296 => 150,  291 => 147,  278 => 137,  274 => 136,  271 => 135,  269 => 134,  267 => 133,  265 => 132,  260 => 129,  252 => 124,  247 => 122,  240 => 117,  236 => 116,  228 => 110,  215 => 103,  211 => 102,  208 => 101,  206 => 100,  204 => 99,  202 => 98,  200 => 97,  195 => 94,  182 => 84,  178 => 83,  175 => 82,  173 => 81,  171 => 80,  169 => 79,  164 => 76,  156 => 71,  151 => 69,  144 => 64,  140 => 63,  132 => 57,  119 => 50,  115 => 49,  112 => 48,  110 => 47,  108 => 46,  106 => 45,  104 => 44,  99 => 41,  86 => 31,  82 => 30,  79 => 29,  77 => 28,  75 => 27,  73 => 26,  68 => 23,  58 => 18,  51 => 16,  44 => 11,  40 => 10,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"ProductTab\">
    <ul class=\"resp-tabs-list hor_1\">
        <li>ΑΝΔΡΑΣ</li>
        <li>ΓΥΝΑΙΚΑ</li>
        <li>ΠΑΙΔΙ</li>
    </ul>
    <div class=\"resp-tabs-container hor_1\">
        <div id=\"men_id\">
            <div class=\"owl-carousel owl-theme ProductScrollTab\">
                {% for pr in popular %}
                    <div class=\"item\">
                        <div class=\"product-case\">
                            <div class=\"tag tag-green\"><span>new</span></div>
                            <div class=\"product-img\">
                                <div class=\"hover-img\">
                                    <img src=\"{{ pr.imageUrl }}\" alt=\"{{ pr.name }}\">
                                </div>
                                <a href=\"#\"><img src=\"{{ pr.imageUrl }}\" alt=\"{{ pr.name }}\"></a>
                            </div>
                            <div class=\"hover-info\">
                                <div class=\"product-short-info\">
                                    <div class=\"product-name\">
                                        <a href=\"#\">{{ pr.name }}</a>
                                    </div>
                                    {#<div class=\"star\"><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"product-price\">
                                        <div class=\"product-price-span\">{{ pr.webPrice }}€
                                            <del>{{ pr.retailPrice }}€</del>
                                        </div>
                                    </div>
                                    <button type=\"button\"><i class=\"fa fa-cart-plus\"></i>
                                        <span>Καλάθι</span>
                                    </button>
                                </div>
                            </div>
                            <div class=\"product-short-info\">
                                <div class=\"product-name\">
                                    <a href=\"#\">{{ pr.name }}</a>
                                </div>
                                {#<div class=\"star\"><i class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i class=\"fa fa-star-o\"></i>#}
                                {#</div>#}
                                <div class=\"product-price\">
                                    <div class=\"product-price-span\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                {% endfor %}
            </div>
        </div>


        <div id=\"women_id\">
            <div class=\"owl-carousel owl-theme ProductScrollTab\">
                {% for pr in popular %}
                    <div class=\"item\">
                        <div class=\"product-case\">
                            <div class=\"tag tag-green\"><span>new</span></div>
                            <div class=\"product-img\">
                                <div class=\"hover-img\">
                                    <img src=\"images/product-1-h.jpg\" alt=\"{{ pr.name }}\">
                                </div>
                                <a href=\"#\"><img src=\"images/product-1.jpg\" alt=\"{{ pr.name }}\"></a>
                            </div>
                            <div class=\"hover-info\">
                                <div class=\"product-short-info\">
                                    <div class=\"product-name\">
                                        <a href=\"#\">{{ pr.name }}</a>
                                    </div>
                                    {#<div class=\"star\"><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"product-price\">
                                        <div class=\"product-price-span\">{{ pr.webPrice }}€
                                            <del>{{ pr.retailPrice }}€</del>
                                        </div>
                                    </div>
                                    <button type=\"button\"><i class=\"fa fa-cart-plus\"></i>
                                        <span>Καλάθι</span>
                                    </button>
                                </div>
                            </div>
                            <div class=\"product-short-info\">
                                <div class=\"product-name\">
                                    <a href=\"#\">{{ pr.name }}</a>
                                </div>
                                {#<div class=\"star\"><i class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i class=\"fa fa-star-o\"></i>#}
                                {#</div>#}
                                <div class=\"product-price\">
                                    <div class=\"product-price-span\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                {% endfor %}
            </div>
        </div>


        <div id=\"acce_id\">
            <div class=\"owl-carousel owl-theme ProductScrollTab\">
                {% for pr in popular %}
                    <div class=\"item\">
                        <div class=\"product-case\">
                            <div class=\"tag tag-green\"><span>new</span></div>
                            <div class=\"product-img\">
                                <div class=\"hover-img\">
                                    <img src=\"images/product-1-h.jpg\" alt=\"{{ pr.name }}\">
                                </div>
                                <a href=\"#\"><img src=\"images/product-1.jpg\" alt=\"{{ pr.name }}\"></a>
                            </div>
                            <div class=\"hover-info\">
                                <div class=\"product-short-info\">
                                    <div class=\"product-name\">
                                        <a href=\"#\">{{ pr.name }}</a>
                                    </div>
                                    {#<div class=\"star\"><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"product-price\">
                                        <div class=\"product-price-span\">{{ pr.webPrice }}€
                                            <del>{{ pr.retailPrice }}€</del>
                                        </div>
                                    </div>
                                    <button type=\"button\"><i class=\"fa fa-cart-plus\"></i>
                                        <span>Καλάθι</span>
                                    </button>
                                </div>
                            </div>
                            <div class=\"product-short-info\">
                                <div class=\"product-name\">
                                    <a href=\"#\">{{ pr.name }}</a>
                                </div>
                                {#<div class=\"star\"><i class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                {#class=\"fa fa-star\"></i><i class=\"fa fa-star-o\"></i>#}
                                {#</div>#}
                                <div class=\"product-price\">
                                    <div class=\"product-price-span\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
</div>", "products/modules/bottom_product_tabs.html.twig", "/var/www/html/anosia/templates/products/modules/bottom_product_tabs.html.twig");
    }
}
