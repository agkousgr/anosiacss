<?php

/* products/modules/aside_shop_by_brand.html.twig */
class __TwigTemplate_736e0a226ca29103339ae87fe90b9a07417f9eb4b00f9697301ff56774436cf7 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/aside_shop_by_brand.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/aside_shop_by_brand.html.twig"));

        // line 1
        echo "<div class=\"filter-widget\">
    <h3>ΜΑΡΚΕΣ</h3>
    <div class=\"content\">
        <div class=\"brand-list clearfix\">
            <div class=\"btn-group clearfix\" data-toggle=\"buttons\">
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-1.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-2.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-3.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-4.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-5.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-6.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-7.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-8.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-9.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-10.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-11.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/brands/brand-12.jpg"), "html", null, true);
        echo "\" alt=\"\"></label>
            </div>
        </div>
        <div class=\"text-right\">
            <button type=\"button\" class=\"btn btn-xs btn-default\">ΕΦΑΡΜΟΓΗ</button>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "products/modules/aside_shop_by_brand.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 29,  87 => 27,  82 => 25,  77 => 23,  72 => 21,  67 => 19,  62 => 17,  57 => 15,  52 => 13,  47 => 11,  42 => 9,  37 => 7,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"filter-widget\">
    <h3>ΜΑΡΚΕΣ</h3>
    <div class=\"content\">
        <div class=\"brand-list clearfix\">
            <div class=\"btn-group clearfix\" data-toggle=\"buttons\">
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-1.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-2.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-3.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-4.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-5.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-6.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-7.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-8.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-9.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-10.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-11.jpg') }}\" alt=\"\"></label>
                <label class=\"btn btn-primary\"><input type=\"checkbox\" autocomplete=\"off\"><img
                            src=\"{{ asset('images/brands/brand-12.jpg') }}\" alt=\"\"></label>
            </div>
        </div>
        <div class=\"text-right\">
            <button type=\"button\" class=\"btn btn-xs btn-default\">ΕΦΑΡΜΟΓΗ</button>
        </div>
    </div>
</div>", "products/modules/aside_shop_by_brand.html.twig", "/var/www/html/anosia/templates/products/modules/aside_shop_by_brand.html.twig");
    }
}
