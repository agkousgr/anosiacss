<?php

/* home_page_modules/06_categories.html.twig */
class __TwigTemplate_066589fead89170db37c55f8d2cc937723ea9acd9e98804d060e04b6dd369fdf extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "home_page_modules/06_categories.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "home_page_modules/06_categories.html.twig"));

        // line 1
        echo "<div class=\"category-banner\">
    <ul>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">MOTHER CARE</div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/cloth.jpg"), "html", null, true);
        echo "\" alt=\"\">
            </div>
        </li>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">
                                Φροντιδα Παιδιου
                            </div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/jeans.jpg"), "html", null, true);
        echo "\" alt=\"\">
            </div>
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">
                                Φροντιδα Βρεφους
                            </div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/watch.jpg"), "html", null, true);
        echo "\" alt=\"\">
            </div>
        </li>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">
                                Αξεσουαρ Βρεφους
                            </div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/eyegear.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">Διατροφη Βρεφους</div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/shoes.jpg"), "html", null, true);
        echo "\" alt=\"\">
            </div>
        </li>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">Φροντιδα Βρεφους</div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/bags.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">BELTS</div>
                        </div>
                    </div>
                </a>
                <img src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/belts.jpg"), "html", null, true);
        echo "\" alt=\"\"></div>
        </li>
    </ul>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "home_page_modules/06_categories.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 82,  118 => 73,  103 => 61,  91 => 52,  74 => 38,  59 => 26,  42 => 12,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"category-banner\">
    <ul>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">MOTHER CARE</div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/cloth.jpg') }}\" alt=\"\">
            </div>
        </li>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">
                                Φροντιδα Παιδιου
                            </div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/jeans.jpg') }}\" alt=\"\">
            </div>
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">
                                Φροντιδα Βρεφους
                            </div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/watch.jpg') }}\" alt=\"\">
            </div>
        </li>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">
                                Αξεσουαρ Βρεφους
                            </div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/eyegear.jpg') }}\" alt=\"\"></div>
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">Διατροφη Βρεφους</div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/shoes.jpg') }}\" alt=\"\">
            </div>
        </li>
        <li class=\"coleql_height\">
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">Φροντιδα Βρεφους</div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/bags.jpg') }}\" alt=\"\"></div>
            <div class=\"banner-img\">
                <a href=\"#\" class=\"overlay\">
                    <div class=\"overlay-box\">
                        <div class=\"table-div\">
                            <div class=\"table-cell-div\">BELTS</div>
                        </div>
                    </div>
                </a>
                <img src=\"{{ asset('images/belts.jpg') }}\" alt=\"\"></div>
        </li>
    </ul>
</div>", "home_page_modules/06_categories.html.twig", "/var/www/html/anosia/templates/home_page_modules/06_categories.html.twig");
    }
}
