<?php

/* products/view.html.twig */
class __TwigTemplate_fbea5c57c0ee4c46bccae27ae6d8f375173f0c46ea96f0f3762128ce37c03efb extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "products/view.html.twig", 1);
        $this->blocks = array(
            'bodyId' => array($this, 'block_bodyId'),
            'title' => array($this, 'block_title'),
            'slider' => array($this, 'block_slider'),
            'breadcrumb' => array($this, 'block_breadcrumb'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/view.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_bodyId($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyId"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyId"));

        echo "category";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " | ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 4, $this->source); })()), "name", array()), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_slider($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "slider"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "slider"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_breadcrumb($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "breadcrumb"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 7
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    <div id=\"mainWrapper\">
        ";
        // line 12
        $this->loadTemplate("partials/sidebar_login.html.twig", "products/view.html.twig", 12)->display($context);
        // line 13
        echo "        ";
        $this->loadTemplate("partials/swipe_menu.html.twig", "products/view.html.twig", 13)->display($context);
        // line 14
        echo "        ";
        $this->loadTemplate("partials/site_header.html.twig", "products/view.html.twig", 14)->display($context);
        // line 15
        echo "        <div class=\"page-header\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\"><h1>";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 18, $this->source); })()), "name", array()), "html", null, true);
        echo "</h1></div>
                </div>
            </div>
        </div>
        <div class=\"section\" style=\"background-image:url(images/bg-5.jpg);\">
            <div class=\"container\">
                <div class=\"col-xs-12\">
                    ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 25, $this->source); })()), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 26
            echo "                        <div class=\"flash-notice\">
                            ";
            // line 27
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "                </div>
                <div class=\"row\">
                    <div class=\"col-md-9 single-product\">
                        <div class=\"row\">
                            <div class=\"col-sm-6\">
                                <div class=\"product-main-slider\">
                                    <div class=\"slider\">
                                        <div class=\"main-image\">
                                            <ul class=\"bxslider\">
                                                <li><img src=\"";
        // line 39
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 39, $this->source); })()), "imageUrl", array()), "html", null, true);
        echo "\" alt=\"\"/></li>
                                                ";
        // line 41
        echo "                                                ";
        // line 42
        echo "                                                ";
        // line 43
        echo "                                                ";
        // line 44
        echo "                                                ";
        // line 45
        echo "                                            </ul>
                                        </div>
                                        <div class=\"owl-carousel owl-theme\" id=\"bx-pager\">
                                            <div class=\"item\"><a data-slide-index=\"0\" href=\"\">
                                                    <img src=\"";
        // line 49
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 49, $this->source); })()), "imageUrl", array()), "html", null, true);
        echo "\" alt=\"\"/></a></div>
                                            ";
        // line 51
        echo "                                            ";
        // line 52
        echo "                                            ";
        // line 53
        echo "                                            ";
        // line 54
        echo "                                            ";
        // line 55
        echo "                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class=\"col-sm-6 wow fadeIn\" data-wow-delay=\"0.3s\">
                                <h2>";
        // line 61
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 61, $this->source); })()), "name", array()), "html", null, true);
        echo "</h2>
                                <p> ";
        // line 62
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 62, $this->source); })()), "summary", array()), "html", null, true);
        echo "</p>
                                ";
        // line 64
        echo "                                ";
        // line 65
        echo "                                ";
        // line 66
        echo "                                ";
        // line 67
        echo "                                ";
        // line 68
        echo "                                ";
        // line 69
        echo "
                                <div class=\"product-id\">SKU : <span>";
        // line 70
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 70, $this->source); })()), "mainBarcode", array()), "html", null, true);
        echo "</span>
                                </div>
                                <div class=\"product-price\">";
        // line 72
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 72, $this->source); })()), "webPrice", array()), 2, ",", "."), "html", null, true);
        echo "
                                    €
                                    <del>";
        // line 74
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 74, $this->source); })()), "retailPrice", array()), 2, ",", "."), "html", null, true);
        echo "€</del>
                                    ";
        // line 75
        if (twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 75, $this->source); })()), "discount", array())) {
            // line 76
            echo "                                        <div class=\"discount\">-";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 76, $this->source); })()), "discount", array()), "html", null, true);
            echo "%</div>
                                    ";
        }
        // line 78
        echo "                                </div>
                                <!-- content availability -->
                                <div class=\"product_attributes clearfix\">
                                    <label>Διαθεσιμότητα:</label>
                                    <span itemprop=\"offers\" itemscope=\"\"
                                          itemtype=\"https://schema.org/Offer\"
                                          class=\"availability\">
                                        ";
        // line 85
        if ((((twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 85, $this->source); })()), "remainNotReserved", array()) > "0") || (twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 85, $this->source); })()), "webFree", array()) == "true")) && (twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 85, $this->source); })()), "outOfStock", array()) == "false"))) {
            // line 86
            echo "                                        <span class=\"available-now\">
                                            <link itemprop=\"availability\"
                                                  href=\"https://schema.org/InStock\">
                                            In Stock
                                        </span>
                                        ";
        } else {
            // line 92
            echo "                                        <span class=\"out-of-stock\">
                                            <link itemprop=\"availability\"
                                                  href=\"https://schema.org/InStock\">
                                            Out of Stock
                                            ";
        }
        // line 97
        echo "                                        </span>
                                    </span>
                                </div>
                                <!-- end content availabity -->

                                ";
        // line 102
        if ((twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 102, $this->source); })()), "maxByOrder", array()) > 0)) {
            // line 103
            echo "                                    ";
            $context["maxItems"] = twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 103, $this->source); })()), "maxByOrder", array());
            // line 104
            echo "                                ";
        } elseif ((twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 104, $this->source); })()), "webFree", array()) == "true")) {
            // line 105
            echo "                                    ";
            $context["maxItems"] = (twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 105, $this->source); })()), "remainNotReserved", array()) + twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 105, $this->source); })()), "overAvailability", array()));
            // line 106
            echo "                                ";
        } else {
            // line 107
            echo "                                    ";
            $context["maxItems"] = twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 107, $this->source); })()), "remainNotReserved", array());
            // line 108
            echo "                                ";
        }
        // line 109
        echo "                                <div class=\"variations_button\">
                                    <div class=\"row\">
                                        <div class=\"col-sm-6\">
                                            <div class=\"form-group\">
                                                <input id=\"add-quantity\"
                                                       class=\"form-control stepper\" type=\"number\"
                                                       value=\"1\" min=\"1\"
                                                       max=\"";
        // line 116
        echo twig_escape_filter($this->env, (isset($context["maxItems"]) || array_key_exists("maxItems", $context) ? $context["maxItems"] : (function () { throw new Twig_Error_Runtime('Variable "maxItems" does not exist.', 116, $this->source); })()), "html", null, true);
        echo "\"/>
                                            </div>
                                        </div>
                                        <div class=\"col-sm-6\">
                                            <ul>
                                                <li>
                                                    <button type=\"button\" class=\"add-to-wishlist\">
                                                        <i class=\"fa fa-heart-o\"></i>
                                                    </button>
                                                </li>
                                                ";
        // line 127
        echo "                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"option_button form-group\">
                                    <div class=\"row\">
                                        <div class=\"col-xs-6\">
                                            <a href=\"\"
                                               class=\"btn btn-primary btn-block add-to-cart\"
                                               data-id=\"";
        // line 137
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 137, $this->source); })()), "id", array()), "html", null, true);
        echo "\"
                                               data-name=\"";
        // line 138
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["pr"]) || array_key_exists("pr", $context) ? $context["pr"] : (function () { throw new Twig_Error_Runtime('Variable "pr" does not exist.', 138, $this->source); })()), "name", array()), "html", null, true);
        echo "\">ΣΤΟ ΚΑΛΑΘΙ</a>
                                        </div>
                                        ";
        // line 141
        echo "                                            ";
        // line 142
        echo "                                                ";
        // line 143
        echo "                                        ";
        // line 144
        echo "                                    </div>
                                </div>
                                <div class=\"share\"><img src=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/share.jpg"), "html", null, true);
        echo "\"
                                                        alt=\"\"></div>

                                <div class=\"pin-widget visible-sm\">
                                    <h5>Delivery</h5>
                                    <div class=\"content\">
                                        <div class=\"pin-form\">
                                            ";
        // line 154
        echo "                                            <div class=\"row no-margin\">
                                                <div class=\"col-xs-8 no-padding\"><input
                                                            type=\"text\" class=\"form-control\"
                                                            placeholder=\"Enter Pin Code\"></div>
                                                <div class=\"col-xs-4 no-padding\"><input
                                                            type=\"submit\"
                                                            class=\"btn btn-primary btn-block\"
                                                            value=\"CHECK\"></div>
                                            </div>
                                            ";
        // line 164
        echo "                                            <p class=\"text-center\">
                                                <strong>Generally delivered by 5
                                                    days</strong></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        ";
        // line 173
        echo twig_include($this->env, $context, "products/modules/product_view_tabs.html.twig");
        echo "
                    </div>

                    <div class=\"col-md-3 sidebar visible-lg visible-md\">
                        ";
        // line 177
        $this->loadTemplate("products/modules/bside_delivery.html.twig", "products/view.html.twig", 177)->display($context);
        // line 178
        echo "                        ";
        $this->loadTemplate("products/modules/bside_special_products.html.twig", "products/view.html.twig", 178)->display($context);
        // line 179
        echo "                        ";
        $this->loadTemplate("products/modules/bside_clearance_sale.html.twig", "products/view.html.twig", 179)->display($context);
        // line 180
        echo "                        ";
        $this->loadTemplate("products/modules/bside_other_info.html.twig", "products/view.html.twig", 180)->display($context);
        // line 181
        echo "                    </div>
                </div>
                ";
        // line 183
        $this->loadTemplate("products/modules/product_view_related.html.twig", "products/view.html.twig", 183)->display($context);
        // line 184
        echo "                ";
        $this->loadTemplate("products/modules/bottom_banners.html.twig", "products/view.html.twig", 184)->display($context);
        // line 185
        echo "

            </div>
        </div>
        ";
        // line 189
        $this->loadTemplate("home_page_modules/14_newsletter.html.twig", "products/view.html.twig", 189)->display($context);
        // line 190
        echo "        ";
        $this->loadTemplate("home_page_modules/15_social.html.twig", "products/view.html.twig", 190)->display($context);
        // line 191
        echo "        ";
        $this->loadTemplate("partials/footer.html.twig", "products/view.html.twig", 191)->display($context);
        // line 192
        echo "    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 195
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 196
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/js/product-list.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "products/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  470 => 197,  465 => 196,  456 => 195,  445 => 192,  442 => 191,  439 => 190,  437 => 189,  431 => 185,  428 => 184,  426 => 183,  422 => 181,  419 => 180,  416 => 179,  413 => 178,  411 => 177,  404 => 173,  393 => 164,  382 => 154,  372 => 146,  368 => 144,  366 => 143,  364 => 142,  362 => 141,  357 => 138,  353 => 137,  341 => 127,  328 => 116,  319 => 109,  316 => 108,  313 => 107,  310 => 106,  307 => 105,  304 => 104,  301 => 103,  299 => 102,  292 => 97,  285 => 92,  277 => 86,  275 => 85,  266 => 78,  260 => 76,  258 => 75,  254 => 74,  249 => 72,  244 => 70,  241 => 69,  239 => 68,  237 => 67,  235 => 66,  233 => 65,  231 => 64,  227 => 62,  223 => 61,  215 => 55,  213 => 54,  211 => 53,  209 => 52,  207 => 51,  203 => 49,  197 => 45,  195 => 44,  193 => 43,  191 => 42,  189 => 41,  185 => 39,  174 => 30,  165 => 27,  162 => 26,  158 => 25,  148 => 18,  143 => 15,  140 => 14,  137 => 13,  135 => 12,  132 => 11,  123 => 10,  112 => 7,  103 => 6,  86 => 5,  67 => 4,  49 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block bodyId %}category{% endblock %}
{% block title %} | {{ pr.name }}{% endblock %}
{% block slider %}{% endblock %}
{% block breadcrumb %}

{% endblock %}

{% block body %}
    <div id=\"mainWrapper\">
        {% include 'partials/sidebar_login.html.twig' %}
        {% include 'partials/swipe_menu.html.twig' %}
        {% include 'partials/site_header.html.twig' %}
        <div class=\"page-header\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\"><h1>{{ pr.name }}</h1></div>
                </div>
            </div>
        </div>
        <div class=\"section\" style=\"background-image:url(images/bg-5.jpg);\">
            <div class=\"container\">
                <div class=\"col-xs-12\">
                    {% for message in app.flashes('notice') %}
                        <div class=\"flash-notice\">
                            {{ message }}
                        </div>
                    {% endfor %}
                </div>
                <div class=\"row\">
                    <div class=\"col-md-9 single-product\">
                        <div class=\"row\">
                            <div class=\"col-sm-6\">
                                <div class=\"product-main-slider\">
                                    <div class=\"slider\">
                                        <div class=\"main-image\">
                                            <ul class=\"bxslider\">
                                                <li><img src=\"{{ pr.imageUrl }}\" alt=\"\"/></li>
                                                {#<li><img src=\"images/img-18.jpg\" alt=\"\" /></li>#}
                                                {#<li><img src=\"images/img-17.jpg\" alt=\"\" /></li>#}
                                                {#<li><img src=\"images/img-18.jpg\" alt=\"\" /></li>#}
                                                {#<li><img src=\"images/img-17.jpg\" alt=\"\" /></li>#}
                                                {#<li><img src=\"images/img-18.jpg\" alt=\"\" /></li>#}
                                            </ul>
                                        </div>
                                        <div class=\"owl-carousel owl-theme\" id=\"bx-pager\">
                                            <div class=\"item\"><a data-slide-index=\"0\" href=\"\">
                                                    <img src=\"{{ pr.imageUrl }}\" alt=\"\"/></a></div>
                                            {#<div class=\"item\"><a data-slide-index=\"1\" href=\"\"><img src=\"images/img-18.jpg\" alt=\"\" /></a></div>#}
                                            {#<div class=\"item\"><a data-slide-index=\"2\" href=\"\"><img src=\"images/img-17.jpg\" alt=\"\" /></a></div>#}
                                            {#<div class=\"item\"><a data-slide-index=\"3\" href=\"\"><img src=\"images/img-18.jpg\" alt=\"\" /></a></div>#}
                                            {#<div class=\"item\"><a data-slide-index=\"4\" href=\"\"><img src=\"images/img-17.jpg\" alt=\"\" /></a></div>#}
                                            {#<div class=\"item\"><a data-slide-index=\"5\" href=\"\"><img src=\"images/img-18.jpg\" alt=\"\" /></a></div>#}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class=\"col-sm-6 wow fadeIn\" data-wow-delay=\"0.3s\">
                                <h2>{{ pr.name }}</h2>
                                <p> {{ pr.summary }}</p>
                                {#<ul class=\"rating\">#}
                                {#<li><i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i>#}
                                {#<i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i></li>#}
                                {#<li><a href=\"#\">(1 customer review)</a></li>#}
                                {#<li><a href=\"#\">Write a Review </a></li>#}
                                {#</ul>#}

                                <div class=\"product-id\">SKU : <span>{{ pr.mainBarcode }}</span>
                                </div>
                                <div class=\"product-price\">{{ pr.webPrice|number_format(2, ',', '.') }}
                                    €
                                    <del>{{ pr.retailPrice|number_format(2, ',', '.') }}€</del>
                                    {% if pr.discount %}
                                        <div class=\"discount\">-{{ pr.discount }}%</div>
                                    {% endif %}
                                </div>
                                <!-- content availability -->
                                <div class=\"product_attributes clearfix\">
                                    <label>Διαθεσιμότητα:</label>
                                    <span itemprop=\"offers\" itemscope=\"\"
                                          itemtype=\"https://schema.org/Offer\"
                                          class=\"availability\">
                                        {% if (pr.remainNotReserved > \"0\" or pr.webFree == \"true\") and pr.outOfStock == \"false\" %}
                                        <span class=\"available-now\">
                                            <link itemprop=\"availability\"
                                                  href=\"https://schema.org/InStock\">
                                            In Stock
                                        </span>
                                        {% else %}
                                        <span class=\"out-of-stock\">
                                            <link itemprop=\"availability\"
                                                  href=\"https://schema.org/InStock\">
                                            Out of Stock
                                            {% endif %}
                                        </span>
                                    </span>
                                </div>
                                <!-- end content availabity -->

                                {% if (pr.maxByOrder > 0) %}
                                    {% set maxItems = pr.maxByOrder %}
                                {% elseif (pr.webFree == 'true') %}
                                    {% set maxItems = pr.remainNotReserved + pr.overAvailability %}
                                {% else %}
                                    {% set maxItems = pr.remainNotReserved %}
                                {% endif %}
                                <div class=\"variations_button\">
                                    <div class=\"row\">
                                        <div class=\"col-sm-6\">
                                            <div class=\"form-group\">
                                                <input id=\"add-quantity\"
                                                       class=\"form-control stepper\" type=\"number\"
                                                       value=\"1\" min=\"1\"
                                                       max=\"{{ maxItems }}\"/>
                                            </div>
                                        </div>
                                        <div class=\"col-sm-6\">
                                            <ul>
                                                <li>
                                                    <button type=\"button\" class=\"add-to-wishlist\">
                                                        <i class=\"fa fa-heart-o\"></i>
                                                    </button>
                                                </li>
                                                {#<li><button type=\"button\"><i class=\"fa fa-bell-o\"></i></button></li>#}
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"option_button form-group\">
                                    <div class=\"row\">
                                        <div class=\"col-xs-6\">
                                            <a href=\"\"
                                               class=\"btn btn-primary btn-block add-to-cart\"
                                               data-id=\"{{ pr.id }}\"
                                               data-name=\"{{ pr.name }}\">ΣΤΟ ΚΑΛΑΘΙ</a>
                                        </div>
                                        {#<div class=\"col-xs-6\">#}
                                            {#<a href=\"#\" class=\"btn btn-default btn-block\">ΑΓΟΡΑΣΕ#}
                                                {#ΤΩΡΑ</a>#}
                                        {#</div>#}
                                    </div>
                                </div>
                                <div class=\"share\"><img src=\"{{ asset('images/share.jpg') }}\"
                                                        alt=\"\"></div>

                                <div class=\"pin-widget visible-sm\">
                                    <h5>Delivery</h5>
                                    <div class=\"content\">
                                        <div class=\"pin-form\">
                                            {#<form action=\"#\">#}
                                            <div class=\"row no-margin\">
                                                <div class=\"col-xs-8 no-padding\"><input
                                                            type=\"text\" class=\"form-control\"
                                                            placeholder=\"Enter Pin Code\"></div>
                                                <div class=\"col-xs-4 no-padding\"><input
                                                            type=\"submit\"
                                                            class=\"btn btn-primary btn-block\"
                                                            value=\"CHECK\"></div>
                                            </div>
                                            {#</form>#}
                                            <p class=\"text-center\">
                                                <strong>Generally delivered by 5
                                                    days</strong></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        {{ include('products/modules/product_view_tabs.html.twig') }}
                    </div>

                    <div class=\"col-md-3 sidebar visible-lg visible-md\">
                        {% include 'products/modules/bside_delivery.html.twig' %}
                        {% include 'products/modules/bside_special_products.html.twig' %}
                        {% include 'products/modules/bside_clearance_sale.html.twig' %}
                        {% include 'products/modules/bside_other_info.html.twig' %}
                    </div>
                </div>
                {% include 'products/modules/product_view_related.html.twig' %}
                {% include 'products/modules/bottom_banners.html.twig' %}


            </div>
        </div>
        {% include 'home_page_modules/14_newsletter.html.twig' %}
        {% include 'home_page_modules/15_social.html.twig' %}
        {% include 'partials/footer.html.twig' %}
    </div>
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script src=\"{{ asset('build/js/product-list.js') }}\"></script>
{% endblock %}", "products/view.html.twig", "/var/www/html/anosia/templates/products/view.html.twig");
    }
}
