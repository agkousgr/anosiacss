<?php

/* blog/list.html.twig */
class __TwigTemplate_26752fd7db9dee64bdf013cd7010acec5dd4dcf6a2a3fa93529ca017d173d800 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "blog/list.html.twig", 1);
        $this->blocks = array(
            'bodyId' => array($this, 'block_bodyId'),
            'title' => array($this, 'block_title'),
            'slider' => array($this, 'block_slider'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'breadcrumb' => array($this, 'block_breadcrumb'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/list.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_bodyId($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyId"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bodyId"));

        echo "category";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " | Το Blog μας";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_slider($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "slider"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "slider"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/css/orders.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_breadcrumb($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "breadcrumb"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 11
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "    ";
        $this->loadTemplate("partials/sidebar_login.html.twig", "blog/list.html.twig", 15)->display($context);
        // line 16
        echo "    ";
        $this->loadTemplate("partials/swipe_menu.html.twig", "blog/list.html.twig", 16)->display($context);
        // line 17
        echo "    ";
        $this->loadTemplate("partials/site_header.html.twig", "blog/list.html.twig", 17)->display($context);
        // line 18
        echo "    <div class=\"page-header\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\"><h1>Το Blog μας</h1></div>
            </div>
        </div>
    </div>
    <div class=\"section\" style=\"background-image:url(";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/bg-5.jpg"), "html", null, true);
        echo ");\">
        <div class=\"container\">
            <div class=\"blog-header\" style=\"background-image:url(images/bg-10.jpg)\">
                <div class=\"row wow flipInX\" data-wow-delay=\"0.4s\">
                    <div class=\"col-sm-8 col-sm-offset-2\">
                        <h3>OUR BLOGS</h3>
                        <h2>Read all our Latest Blogs</h2>
                        <p>Nam in docendi reprimique, laoreet honestatis eu mel. Id qui aperiri admodum intellegat, ea
                            illum populo qui. An modo eleifend vituperatoribus his, id has oporteat honestatis, has quas
                            efficiendi eu. </p>
                    </div>
                </div>
            </div>


            <div class=\"row\">
                <div class=\"col-sm-8 col-md-9\">
                    <div class=\"post-list\">
                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-1.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-2.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-3.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-4.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-5.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-6.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <nav aria-label=\"Page navigation\">
                        <ul class=\"pagination\">
                            <li>
                                <a href=\"#\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">«</span>
                                </a>
                            </li>
                            <li class=\"active\"><a href=\"#\">1</a></li>
                            <li><a href=\"#\">2</a></li>
                            <li><a href=\"#\">3</a></li>
                            <li><a href=\"#\">4</a></li>
                            <li><a href=\"#\">5</a></li>
                            <li>
                                <a href=\"#\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">»</span>
                                </a>
                            </li>
                        </ul>
                    </nav>

                </div>


                <div class=\"col-sm-4 col-md-3 right-col\">
                    <div class=\"widget-box\">
                        <div class=\"blog-search\">
                            <form method=\"post\" action=\"#\">
                                <input placeholder=\"Search Blog\" class=\"form-control\" type=\"text\">
                                <button type=\"submit\"><i class=\"fa fa-search\"></i></button>
                            </form>
                        </div>
                    </div>

                    ";
        // line 331
        echo "                        ";
        // line 332
        echo "                        ";
        // line 333
        echo "                            ";
        // line 334
        echo "                                ";
        // line 335
        echo "                                ";
        // line 336
        echo "                                ";
        // line 337
        echo "                                ";
        // line 338
        echo "                                ";
        // line 339
        echo "                                ";
        // line 340
        echo "                                ";
        // line 341
        echo "                            ";
        // line 342
        echo "                        ";
        // line 343
        echo "                    ";
        // line 344
        echo "
                    <div class=\"widget-box\">
                        <h3>popolar post</h3>
                        <div class=\"pop-post\">
                            <div class=\"media\">
                                <div class=\"media-left\"><a href=\"#\"><img class=\"media-object\"
                                                                         src=\"images/slide-1-sm.jpg\" alt=\"...\"></a>
                                </div>
                                <div class=\"media-body\">
                                    <h6>The Most Readed Blog Post Here</h6>
                                    <a href=\"#\"><strong>Read More</strong> <i class=\"fa fa-arrow-right\"></i></a>
                                </div>
                            </div>
                            <ul>
                                <li><i class=\"fa fa-calendar-o\"></i><a href=\"#\">November</a> 11, 2016</li>
                                <li><i class=\"fa fa-comments-o\"></i><a href=\"#\">5 comment(s)</a></li>
                            </ul>
                        </div>
                        <div class=\"pop-post\">
                            <div class=\"media\">
                                <div class=\"media-left\"><a href=\"#\"><img class=\"media-object\" src=\"images/img-3.jpg\"
                                                                         alt=\"...\"></a></div>
                                <div class=\"media-body\">
                                    <h6>The Most Readed Blog Post Here</h6>
                                    <a href=\"#\"><strong>Read More</strong> <i class=\"fa fa-arrow-right\"></i></a>
                                </div>
                            </div>
                            <ul>
                                <li><i class=\"fa fa-calendar-o\"></i><a href=\"#\">November</a> 11, 2016</li>
                                <li><i class=\"fa fa-comments-o\"></i><a href=\"#\">5 comment(s)</a></li>
                            </ul>
                        </div>
                        <div class=\"pop-post\">
                            <div class=\"media\">
                                <div class=\"media-left\"><a href=\"#\"><img class=\"media-object\" src=\"images/img-7.jpg\"
                                                                         alt=\"...\"></a></div>
                                <div class=\"media-body\">
                                    <h6>The Most Readed Blog Post Here</h6>
                                    <a href=\"#\"><strong>Read More</strong> <i class=\"fa fa-arrow-right\"></i></a>
                                </div>
                            </div>
                            <ul>
                                <li><i class=\"fa fa-calendar-o\"></i><a href=\"#\">November</a> 11, 2016</li>
                                <li><i class=\"fa fa-comments-o\"></i><a href=\"#\">5 comment(s)</a></li>
                            </ul>
                        </div>
                    </div>


                    ";
        // line 393
        $this->loadTemplate("products/modules/aside_best_sellers.html.twig", "blog/list.html.twig", 393)->display($context);
        // line 394
        echo "
                    <div class=\"widget-box\">
                        <div class=\"fb-page\" data-href=\"#\" data-tabs=\"timeline\" data-height=\"648\"
                             data-small-header=\"false\" data-adapt-container-width=\"true\" data-hide-cover=\"false\"
                             data-show-facepile=\"true\">
                            <blockquote cite=\"#\" class=\"fb-xfbml-parse-ignore\"><a href=\"#\">Facebook</a></blockquote>
                        </div>
                    </div>

                </div>


            </div>
        </div>
        ";
        // line 408
        $this->loadTemplate("home_page_modules/14_newsletter.html.twig", "blog/list.html.twig", 408)->display($context);
        // line 409
        echo "        ";
        $this->loadTemplate("home_page_modules/15_social.html.twig", "blog/list.html.twig", 409)->display($context);
        // line 410
        echo "        ";
        $this->loadTemplate("partials/footer.html.twig", "blog/list.html.twig", 410)->display($context);
        // line 411
        echo "    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  586 => 411,  583 => 410,  580 => 409,  578 => 408,  562 => 394,  560 => 393,  509 => 344,  507 => 343,  505 => 342,  503 => 341,  501 => 340,  499 => 339,  497 => 338,  495 => 337,  493 => 336,  491 => 335,  489 => 334,  487 => 333,  485 => 332,  483 => 331,  175 => 25,  166 => 18,  163 => 17,  160 => 16,  157 => 15,  148 => 14,  137 => 11,  128 => 10,  116 => 8,  111 => 7,  102 => 6,  85 => 5,  67 => 4,  49 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block bodyId %}category{% endblock %}
{% block title %} | Το Blog μας{% endblock %}
{% block slider %}{% endblock %}
{% block stylesheets %}
    {{ parent() }}
    <link href=\"{{ asset('build/css/orders.css') }}\" rel=\"stylesheet\"/>
{% endblock %}
{% block breadcrumb %}

{% endblock %}

{% block body %}
    {% include 'partials/sidebar_login.html.twig' %}
    {% include 'partials/swipe_menu.html.twig' %}
    {% include 'partials/site_header.html.twig' %}
    <div class=\"page-header\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\"><h1>Το Blog μας</h1></div>
            </div>
        </div>
    </div>
    <div class=\"section\" style=\"background-image:url({{ asset('images/bg-5.jpg') }});\">
        <div class=\"container\">
            <div class=\"blog-header\" style=\"background-image:url(images/bg-10.jpg)\">
                <div class=\"row wow flipInX\" data-wow-delay=\"0.4s\">
                    <div class=\"col-sm-8 col-sm-offset-2\">
                        <h3>OUR BLOGS</h3>
                        <h2>Read all our Latest Blogs</h2>
                        <p>Nam in docendi reprimique, laoreet honestatis eu mel. Id qui aperiri admodum intellegat, ea
                            illum populo qui. An modo eleifend vituperatoribus his, id has oporteat honestatis, has quas
                            efficiendi eu. </p>
                    </div>
                </div>
            </div>


            <div class=\"row\">
                <div class=\"col-sm-8 col-md-9\">
                    <div class=\"post-list\">
                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-1.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-2.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-3.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-4.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-5.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"post-article wow fadeIn\" data-wow-delay=\"0.4s\">
                            <div class=\"row no-margin\">
                                <div class=\"col-md-7 no-padding\">
                                    <div class=\"blog-img coleql_height\">
                                        <div class=\"post-img \"
                                             style=\"background-image:url(images/post-img-6.jpg)\"></div>
                                    </div>
                                </div>
                                <div class=\"col-md-5 no-padding\">
                                    <div class=\"post-article-content coleql_height\">
                                        <h3><a href=\"#\">The Daily Reporter Selects Gilbane Building Company.</a></h3>
                                        <p>Esse postea sensibus pri an, eu essent inimicus reformidans sea. Alienum
                                            appetere qui ei, sint consetetur ad vel. Unum posse at vis. Quo vero mundi
                                            labores te.</p>
                                        <ul class=\"postmeta\">
                                            <li><i class=\"fa fa-calendar\"></i>12 february, <a href=\"#\">2015</a></li>
                                            <li><i class=\"fa fa-comments\"></i><a href=\"#\">23 comments</a></li>
                                            <li><i class=\"fa fa-user-circle-o\"></i>by <a href=\"#\">Admin</a></li>
                                        </ul>
                                        <div class=\"clearfix\">
                                            <a href=\"#\" class=\"btn btn-primary pull-left\">Read More</a>
                                            <div class=\"share pull-right\">
                                                <p>
                                                    <small>Share this post:</small>
                                                </p>
                                                <ul>
                                                    <li><a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"gplus\"><i class=\"fa fa-google-plus\"></i></a>
                                                    </li>
                                                    <li><a href=\"#\" class=\"pinterest\"><i
                                                                    class=\"fa fa-pinterest\"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <nav aria-label=\"Page navigation\">
                        <ul class=\"pagination\">
                            <li>
                                <a href=\"#\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">«</span>
                                </a>
                            </li>
                            <li class=\"active\"><a href=\"#\">1</a></li>
                            <li><a href=\"#\">2</a></li>
                            <li><a href=\"#\">3</a></li>
                            <li><a href=\"#\">4</a></li>
                            <li><a href=\"#\">5</a></li>
                            <li>
                                <a href=\"#\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">»</span>
                                </a>
                            </li>
                        </ul>
                    </nav>

                </div>


                <div class=\"col-sm-4 col-md-3 right-col\">
                    <div class=\"widget-box\">
                        <div class=\"blog-search\">
                            <form method=\"post\" action=\"#\">
                                <input placeholder=\"Search Blog\" class=\"form-control\" type=\"text\">
                                <button type=\"submit\"><i class=\"fa fa-search\"></i></button>
                            </form>
                        </div>
                    </div>

                    {#<div class=\"widget-box\">#}
                        {#<h3>Categories</h3>#}
                        {#<div class=\"category-list\">#}
                            {#<ul>#}
                                {#<li><a href=\"#\">About us <span>(1)</span></a></li>#}
                                {#<li><a href=\"#\">Checkerboard <span>(10)</span></a></li>#}
                                {#<li><a href=\"#\">Fashion <span>(8)</span></a></li>#}
                                {#<li><a href=\"#\">Lifestyle <span>(5)</span></a></li>#}
                                {#<li><a href=\"#\">Nature <span>(7)</span></a></li>#}
                                {#<li><a href=\"#\">Travel <span>(3)</span></a></li>#}
                                {#<li><a href=\"#\">Types <span>(3)</span></a></li>#}
                            {#</ul>#}
                        {#</div>#}
                    {#</div>#}

                    <div class=\"widget-box\">
                        <h3>popolar post</h3>
                        <div class=\"pop-post\">
                            <div class=\"media\">
                                <div class=\"media-left\"><a href=\"#\"><img class=\"media-object\"
                                                                         src=\"images/slide-1-sm.jpg\" alt=\"...\"></a>
                                </div>
                                <div class=\"media-body\">
                                    <h6>The Most Readed Blog Post Here</h6>
                                    <a href=\"#\"><strong>Read More</strong> <i class=\"fa fa-arrow-right\"></i></a>
                                </div>
                            </div>
                            <ul>
                                <li><i class=\"fa fa-calendar-o\"></i><a href=\"#\">November</a> 11, 2016</li>
                                <li><i class=\"fa fa-comments-o\"></i><a href=\"#\">5 comment(s)</a></li>
                            </ul>
                        </div>
                        <div class=\"pop-post\">
                            <div class=\"media\">
                                <div class=\"media-left\"><a href=\"#\"><img class=\"media-object\" src=\"images/img-3.jpg\"
                                                                         alt=\"...\"></a></div>
                                <div class=\"media-body\">
                                    <h6>The Most Readed Blog Post Here</h6>
                                    <a href=\"#\"><strong>Read More</strong> <i class=\"fa fa-arrow-right\"></i></a>
                                </div>
                            </div>
                            <ul>
                                <li><i class=\"fa fa-calendar-o\"></i><a href=\"#\">November</a> 11, 2016</li>
                                <li><i class=\"fa fa-comments-o\"></i><a href=\"#\">5 comment(s)</a></li>
                            </ul>
                        </div>
                        <div class=\"pop-post\">
                            <div class=\"media\">
                                <div class=\"media-left\"><a href=\"#\"><img class=\"media-object\" src=\"images/img-7.jpg\"
                                                                         alt=\"...\"></a></div>
                                <div class=\"media-body\">
                                    <h6>The Most Readed Blog Post Here</h6>
                                    <a href=\"#\"><strong>Read More</strong> <i class=\"fa fa-arrow-right\"></i></a>
                                </div>
                            </div>
                            <ul>
                                <li><i class=\"fa fa-calendar-o\"></i><a href=\"#\">November</a> 11, 2016</li>
                                <li><i class=\"fa fa-comments-o\"></i><a href=\"#\">5 comment(s)</a></li>
                            </ul>
                        </div>
                    </div>


                    {% include 'products/modules/aside_best_sellers.html.twig' %}

                    <div class=\"widget-box\">
                        <div class=\"fb-page\" data-href=\"#\" data-tabs=\"timeline\" data-height=\"648\"
                             data-small-header=\"false\" data-adapt-container-width=\"true\" data-hide-cover=\"false\"
                             data-show-facepile=\"true\">
                            <blockquote cite=\"#\" class=\"fb-xfbml-parse-ignore\"><a href=\"#\">Facebook</a></blockquote>
                        </div>
                    </div>

                </div>


            </div>
        </div>
        {% include 'home_page_modules/14_newsletter.html.twig' %}
        {% include 'home_page_modules/15_social.html.twig' %}
        {% include 'partials/footer.html.twig' %}
    </div>
{% endblock %}

", "blog/list.html.twig", "/var/www/html/anosia/templates/blog/list.html.twig");
    }
}
