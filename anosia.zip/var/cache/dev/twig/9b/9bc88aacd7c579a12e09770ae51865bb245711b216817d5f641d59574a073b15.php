<?php

/* products/modules/aside_size.html.twig */
class __TwigTemplate_6bd6da6a1740302b0745a2532ee9dacc230732703642628ead0c892cf8e357bf extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/aside_size.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/aside_size.html.twig"));

        // line 1
        echo "<div class=\"filter-widget\">
    <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
        <div class=\"panel panel-default\">
            <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
                <div class=\"panel-title\"><a role=\"button\" data-toggle=\"collapse\"
                                            data-parent=\"#accordion\" href=\"#collapseSize\"
                                            aria-expanded=\"true\"
                                            aria-controls=\"collapseSize\">Size</a></div>
            </div>
            <div id=\"collapseSize\" class=\"panel-collapse collapse in\" role=\"tabpanel\"
                 aria-labelledby=\"headingSize\">
                <div class=\"panel-body\">
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>XXS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>3XS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>2XS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>XS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>S</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>M</span></label>
                    </div>
                    <div class=\"text-right\">
                        <button type=\"button\" class=\"btn btn-xs btn-default\">APPLY</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "products/modules/aside_size.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"filter-widget\">
    <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
        <div class=\"panel panel-default\">
            <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
                <div class=\"panel-title\"><a role=\"button\" data-toggle=\"collapse\"
                                            data-parent=\"#accordion\" href=\"#collapseSize\"
                                            aria-expanded=\"true\"
                                            aria-controls=\"collapseSize\">Size</a></div>
            </div>
            <div id=\"collapseSize\" class=\"panel-collapse collapse in\" role=\"tabpanel\"
                 aria-labelledby=\"headingSize\">
                <div class=\"panel-body\">
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>XXS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>3XS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>2XS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>XS</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>S</span></label>
                    </div>
                    <div class=\"custom-cr\"><label><input type=\"checkbox\"
                                                         class=\"checkbox\"><span>M</span></label>
                    </div>
                    <div class=\"text-right\">
                        <button type=\"button\" class=\"btn btn-xs btn-default\">APPLY</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>", "products/modules/aside_size.html.twig", "/var/www/html/anosia/templates/products/modules/aside_size.html.twig");
    }
}
