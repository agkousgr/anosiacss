<?php

/* products/modules/bottom_banners.html.twig */
class __TwigTemplate_fb7d050fa84030253171bd707d0ecdb47f6b483460cc270287079e25eb1f0835 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/bottom_banners.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "products/modules/bottom_banners.html.twig"));

        // line 1
        echo "<div class=\"row bottom-banners\">
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/banner-6.jpg"), "html", null, true);
        echo "\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/banner-7.jpg"), "html", null, true);
        echo "\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/banner-8.jpg"), "html", null, true);
        echo "\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/banner-9.jp"), "html", null, true);
        echo "g\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "products/modules/bottom_banners.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 35,  61 => 25,  48 => 15,  35 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"row bottom-banners\">
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"{{ asset('images/banner-6.jpg') }}\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"{{ asset('images/banner-7.jpg') }}\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"{{ asset('images/banner-8.jpg') }}\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
    <div class=\"col-sm-6\">
        <div class=\"side-banner wow flipInX\" data-wow-delay=\"0.3s\"><a href=\"#\">
                <div class=\"grid\">
                    <figure class=\"effect-apollo\"><img src=\"{{ asset('images/banner-9.jp') }}g\"
                                                       alt=\"\">
                        <figcaption></figcaption>
                    </figure>
                </div>
            </a></div>
    </div>
</div>", "products/modules/bottom_banners.html.twig", "/var/www/html/anosia/templates/products/modules/bottom_banners.html.twig");
    }
}
