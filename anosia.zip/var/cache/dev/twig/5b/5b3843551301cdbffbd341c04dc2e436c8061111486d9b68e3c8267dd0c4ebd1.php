<?php

/* partials/sidebar_login.html.twig */
class __TwigTemplate_70eb6f22a58af2e66a4f5517c41a2983a7776f824434305cf28baabe5cad03d6 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/sidebar_login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/sidebar_login.html.twig"));

        // line 1
        echo "<div id=\"sidebar-wrapper\">
    <div class=\"sidebar-logo clearfix\">
        <div class=\"logo-sidebar\"><a href=\"#\"><img src=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/images/logo.png"), "html", null, true);
        echo "\"
                                                   alt=\"\"></a></div>
        <a id=\"menu-close\" href=\"#\" class=\"close-menu\">Close Menu</a>
    </div>

    <div class=\"sidebar-login\">
        ";
        // line 9
        if ( !twig_test_empty((isset($context["loggedUser"]) || array_key_exists("loggedUser", $context) ? $context["loggedUser"] : (function () { throw new Twig_Error_Runtime('Variable "loggedUser" does not exist.', 9, $this->source); })()))) {
            // line 10
            echo "        <ul>
            <li class=\"user\">Καλώς ήρθες <a href=\"";
            // line 11
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_account");
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["loggedUser"]) || array_key_exists("loggedUser", $context) ? $context["loggedUser"] : (function () { throw new Twig_Error_Runtime('Variable "loggedUser" does not exist.', 11, $this->source); })()), "html", null, true);
            echo "</a></li>
            <li class=\"logout\"><a href=\"";
            // line 12
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
            echo "\">Αποσύνδεση</a> </li>
        </ul>
        ";
        } else {
            // line 15
            echo "        <h4>ΕΙΣΟΔΟΣ</h4>
        <form action=\"";
            // line 16
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
            echo "\" method=\"post\">
            <div class=\"form-group\">
                <input name=\"_username\" required type=\"text\" class=\"form-control\" placeholder=\"Όνομα χρήστη\">
            </div>
            <div class=\"form-group\">
                <input name=\"_password\" required type=\"password\" class=\"form-control\" placeholder=\"Κωδικός\">
            </div>
            <div class=\"clearfix\">
                <div class=\"form-group pull-left\">
                    <label><input type=\"checkbox\"> Να με θυμάσαι</label>
                </div>
                <a href=\"#\" class=\"pull-right\">Ξεχάσατε τον κωδικό σας?</a>
            </div>
            <div class=\"form-group text-center\">
                <button type=\"submit\" class=\"btn btn-primary btn-signin\">ΕΙΣΟΔΟΣ</button>
            </div>
            <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
            echo "\">
        </form>

        <div class=\"form-group text-center\">
            <a href=\"";
            // line 36
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_registration");
            echo "\"><strong>ΕΓΓΡΑΦΗ ΤΩΡΑ</strong></a>
        </div>

        <div class=\"form-group\">
            <div class=\"fb-login-button\" data-max-rows=\"1\" data-size=\"large\"
                 data-button-type=\"continue_with\" data-show-faces=\"false\"
                 data-auto-logout-link=\"false\" data-use-continue-as=\"false\">
            </div>
        </div>
        ";
            // line 46
            echo "        ";
        }
        // line 47
        echo "
        <ul>
            <li class=\"call\">210 94 02 027<span>Καλέστε μας</span></li>
            <li class=\"email\">support@anociapharmacy.gr<span>Επικοινωνείστε μαζί μας</span></li>
        </ul>

        <div class=\"sidebar-product-list\">
            <h3>Best <span>Seller</span></h3>
            <div id=\"carouselOneSidebar\" class=\"carousel slide\" data-ride=\"carousel\">
                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                    <div class=\"item active\">
                        ";
        // line 59
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, (isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 59, $this->source); })()), 0, 4));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 60
            echo "                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">
                                        <img class=\"media-object\" src=\"";
            // line 63
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
            echo "\"
                                             alt=\"";
            // line 64
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"";
            // line 69
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </h5>
                                    ";
            // line 72
            echo "                                    ";
            // line 73
            echo "                                    ";
            // line 74
            echo "                                    <div class=\"price\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 75
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "                    </div>
                    <div class=\"item\">
                        ";
        // line 84
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, (isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 84, $this->source); })()), 0, 4));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 85
            echo "                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"";
            // line 87
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">
                                        <img class=\"media-object\" src=\"";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
            echo "\"
                                             alt=\"";
            // line 89
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"";
            // line 94
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </h5>
                                    ";
            // line 97
            echo "                                    ";
            // line 98
            echo "                                    ";
            // line 99
            echo "                                    <div class=\"price\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 100
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 107
        echo "                    </div>
                    <div class=\"carousel-nav\">
                        <a class=\"left carousel-control\" href=\"#carouselOneSidebar\" role=\"button\"
                           data-slide=\"prev\">Previous</a>
                        <a class=\"right carousel-control\" href=\"#carouselOneSidebar\" role=\"button\"
                           data-slide=\"next\">Next</a>
                    </div>
                </div>
            </div>
        </div>

        <div class=\"sidebar-product-list\">
            <h3>ΝΕΕΣ <span>ΑΦΙΞΕΙΣ</span></h3>
            <div id=\"carouselTwoSidebar\" class=\"carousel slide\" data-ride=\"carousel\">
                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                    <div class=\"item active\">
                        ";
        // line 124
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, (isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 124, $this->source); })()), 0, 4));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 125
            echo "                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"";
            // line 127
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">
                                        <img class=\"media-object\" src=\"";
            // line 128
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
            echo "\"
                                             alt=\"";
            // line 129
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"";
            // line 134
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </h5>
                                    ";
            // line 137
            echo "                                    ";
            // line 138
            echo "                                    ";
            // line 139
            echo "                                    <div class=\"price\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 140
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 147
        echo "                    </div>
                    <div class=\"item\">
                        ";
        // line 149
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, (isset($context["popular"]) || array_key_exists("popular", $context) ? $context["popular"] : (function () { throw new Twig_Error_Runtime('Variable "popular" does not exist.', 149, $this->source); })()), 0, 4));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 150
            echo "                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"";
            // line 152
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">
                                        <img class=\"media-object\" src=\"";
            // line 153
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "imageUrl", array()), "html", null, true);
            echo "\"
                                             alt=\"";
            // line 154
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"";
            // line 159
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_view", array("id" => twig_get_attribute($this->env, $this->source, $context["pr"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "name", array()), "html", null, true);
            echo "</a>
                                    </h5>
                                    ";
            // line 162
            echo "                                    ";
            // line 163
            echo "                                    ";
            // line 164
            echo "                                    <div class=\"price\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "webPrice", array()), "html", null, true);
            echo "€
                                        <del>";
            // line 165
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["pr"], "retailPrice", array()), "html", null, true);
            echo "€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 172
        echo "                    </div>
                    <div class=\"carousel-nav\">
                        <a class=\"left carousel-control\" href=\"#carouselTwoSidebar\" role=\"button\"
                           data-slide=\"prev\">Previous</a>
                        <a class=\"right carousel-control\" href=\"#carouselTwoSidebar\" role=\"button\"
                           data-slide=\"next\">Next</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "partials/sidebar_login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  356 => 172,  343 => 165,  338 => 164,  336 => 163,  334 => 162,  327 => 159,  319 => 154,  315 => 153,  311 => 152,  307 => 150,  303 => 149,  299 => 147,  286 => 140,  281 => 139,  279 => 138,  277 => 137,  270 => 134,  262 => 129,  258 => 128,  254 => 127,  250 => 125,  246 => 124,  227 => 107,  214 => 100,  209 => 99,  207 => 98,  205 => 97,  198 => 94,  190 => 89,  186 => 88,  182 => 87,  178 => 85,  174 => 84,  170 => 82,  157 => 75,  152 => 74,  150 => 73,  148 => 72,  141 => 69,  133 => 64,  129 => 63,  125 => 62,  121 => 60,  117 => 59,  103 => 47,  100 => 46,  88 => 36,  81 => 32,  62 => 16,  59 => 15,  53 => 12,  47 => 11,  44 => 10,  42 => 9,  33 => 3,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"sidebar-wrapper\">
    <div class=\"sidebar-logo clearfix\">
        <div class=\"logo-sidebar\"><a href=\"#\"><img src=\"{{ asset('build/images/logo.png') }}\"
                                                   alt=\"\"></a></div>
        <a id=\"menu-close\" href=\"#\" class=\"close-menu\">Close Menu</a>
    </div>

    <div class=\"sidebar-login\">
        {% if (loggedUser is not empty) %}
        <ul>
            <li class=\"user\">Καλώς ήρθες <a href=\"{{ path('user_account') }}\">{{ loggedUser }}</a></li>
            <li class=\"logout\"><a href=\"{{ path('logout') }}\">Αποσύνδεση</a> </li>
        </ul>
        {% else %}
        <h4>ΕΙΣΟΔΟΣ</h4>
        <form action=\"{{ path('login') }}\" method=\"post\">
            <div class=\"form-group\">
                <input name=\"_username\" required type=\"text\" class=\"form-control\" placeholder=\"Όνομα χρήστη\">
            </div>
            <div class=\"form-group\">
                <input name=\"_password\" required type=\"password\" class=\"form-control\" placeholder=\"Κωδικός\">
            </div>
            <div class=\"clearfix\">
                <div class=\"form-group pull-left\">
                    <label><input type=\"checkbox\"> Να με θυμάσαι</label>
                </div>
                <a href=\"#\" class=\"pull-right\">Ξεχάσατε τον κωδικό σας?</a>
            </div>
            <div class=\"form-group text-center\">
                <button type=\"submit\" class=\"btn btn-primary btn-signin\">ΕΙΣΟΔΟΣ</button>
            </div>
            <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\">
        </form>

        <div class=\"form-group text-center\">
            <a href=\"{{ path('user_registration') }}\"><strong>ΕΓΓΡΑΦΗ ΤΩΡΑ</strong></a>
        </div>

        <div class=\"form-group\">
            <div class=\"fb-login-button\" data-max-rows=\"1\" data-size=\"large\"
                 data-button-type=\"continue_with\" data-show-faces=\"false\"
                 data-auto-logout-link=\"false\" data-use-continue-as=\"false\">
            </div>
        </div>
        {#<div class=\"form-group\"><a href=\"#\" class=\"signin-with-gplus\">Signin with <strong>Google+</strong></a></div>#}
        {% endif %}

        <ul>
            <li class=\"call\">210 94 02 027<span>Καλέστε μας</span></li>
            <li class=\"email\">support@anociapharmacy.gr<span>Επικοινωνείστε μαζί μας</span></li>
        </ul>

        <div class=\"sidebar-product-list\">
            <h3>Best <span>Seller</span></h3>
            <div id=\"carouselOneSidebar\" class=\"carousel slide\" data-ride=\"carousel\">
                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                    <div class=\"item active\">
                        {% for pr in popular|slice(0,4) %}
                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"{{ path('product_view', {'id':pr.id}) }}\">
                                        <img class=\"media-object\" src=\"{{ pr.imageUrl }}\"
                                             alt=\"{{ pr.name }}\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"{{ path('product_view', {'id':pr.id}) }}\">{{ pr.name }}</a>
                                    </h5>
                                    {#<div class=\"star-rating\"><i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"price\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        {% endfor %}
                    </div>
                    <div class=\"item\">
                        {% for pr in popular|slice(0,4) %}
                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"{{ path('product_view', {'id':pr.id}) }}\">
                                        <img class=\"media-object\" src=\"{{ pr.imageUrl }}\"
                                             alt=\"{{ pr.name }}\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"{{ path('product_view', {'id':pr.id}) }}\">{{ pr.name }}</a>
                                    </h5>
                                    {#<div class=\"star-rating\"><i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"price\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        {% endfor %}
                    </div>
                    <div class=\"carousel-nav\">
                        <a class=\"left carousel-control\" href=\"#carouselOneSidebar\" role=\"button\"
                           data-slide=\"prev\">Previous</a>
                        <a class=\"right carousel-control\" href=\"#carouselOneSidebar\" role=\"button\"
                           data-slide=\"next\">Next</a>
                    </div>
                </div>
            </div>
        </div>

        <div class=\"sidebar-product-list\">
            <h3>ΝΕΕΣ <span>ΑΦΙΞΕΙΣ</span></h3>
            <div id=\"carouselTwoSidebar\" class=\"carousel slide\" data-ride=\"carousel\">
                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                    <div class=\"item active\">
                        {% for pr in popular|slice(0,4) %}
                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"{{ path('product_view', {'id':pr.id}) }}\">
                                        <img class=\"media-object\" src=\"{{ pr.imageUrl }}\"
                                             alt=\"{{ pr.name }}\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"{{ path('product_view', {'id':pr.id}) }}\">{{ pr.name }}</a>
                                    </h5>
                                    {#<div class=\"star-rating\"><i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"price\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        {% endfor %}
                    </div>
                    <div class=\"item\">
                        {% for pr in popular|slice(0,4) %}
                            <div class=\"media\">
                                <div class=\"media-left\">
                                    <a href=\"{{ path('product_view', {'id':pr.id}) }}\">
                                        <img class=\"media-object\" src=\"{{ pr.imageUrl }}\"
                                             alt=\"{{ pr.name }}\">
                                    </a>
                                </div>
                                <div class=\"media-body\">
                                    <h5>
                                        <a href=\"{{ path('product_view', {'id':pr.id}) }}\">{{ pr.name }}</a>
                                    </h5>
                                    {#<div class=\"star-rating\"><i class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star\"></i><i class=\"fa fa-star\"></i><i#}
                                    {#class=\"fa fa-star-o\"></i></div>#}
                                    <div class=\"price\">{{ pr.webPrice }}€
                                        <del>{{ pr.retailPrice }}€</del>
                                    </div>
                                    <button type=\"button\" class=\"btn btn-primary btn-xs\">ΚΑΛΑΘΙ
                                    </button>
                                </div>
                            </div>
                        {% endfor %}
                    </div>
                    <div class=\"carousel-nav\">
                        <a class=\"left carousel-control\" href=\"#carouselTwoSidebar\" role=\"button\"
                           data-slide=\"prev\">Previous</a>
                        <a class=\"right carousel-control\" href=\"#carouselTwoSidebar\" role=\"button\"
                           data-slide=\"next\">Next</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>", "partials/sidebar_login.html.twig", "/var/www/html/anosia/templates/partials/sidebar_login.html.twig");
    }
}
