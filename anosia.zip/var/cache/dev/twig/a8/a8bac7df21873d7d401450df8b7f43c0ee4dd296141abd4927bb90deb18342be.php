<?php

/* partials/swipe_menu.html.twig */
class __TwigTemplate_1273171ea9e8cdab1be4b77d25da0553ab978e370bfc857fb8895b5461c91d96 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/swipe_menu.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/swipe_menu.html.twig"));

        // line 1
        echo "<div class=\"large-modal modal fade\" id=\"menuModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-content\">
        <div class=\"close-modal\" data-dismiss=\"modal\">
            <div class=\"lr\">
                <div class=\"rl\"></div>
            </div>
        </div>
        <div class=\"container\">
            <ul id=\"blue-mobile-menu\">
                <li><a href=\"#\">Home</a></li>
                ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) || array_key_exists("categories", $context) ? $context["categories"] : (function () { throw new Twig_Error_Runtime('Variable "categories" does not exist.', 11, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["ctg"]) {
            // line 12
            echo "                    ";
            if ((twig_get_attribute($this->env, $this->source, $context["ctg"], "isVisible", array()) == "1")) {
                // line 13
                echo "                        <li><a href=\"#\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ctg"], "name", array()), "html", null, true);
                echo "</a></li>
                        ";
                // line 14
                if (twig_get_attribute($this->env, $this->source, $context["ctg"], "children", array())) {
                    // line 15
                    echo "                            <ul>
                                ";
                    // line 16
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["ctg"], "children", array()));
                    foreach ($context['_seq'] as $context["_key"] => $context["subctg"]) {
                        // line 17
                        echo "                                    ";
                        if ((twig_get_attribute($this->env, $this->source, $context["subctg"], "isVisible", array()) == "1")) {
                            // line 18
                            echo "                                        <li>
                                            <a href=\"";
                            // line 19
                            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products_list", array("id" => twig_get_attribute($this->env, $this->source, $context["subctg"], "id", array()))), "html", null, true);
                            echo "\">";
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["subctg"], "name", array()), "html", null, true);
                            echo "</a>
                                        </li>
                                    ";
                        }
                        // line 22
                        echo "                                ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['subctg'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 23
                    echo "                            </ul>
                        ";
                }
                // line 25
                echo "                    ";
            }
            // line 26
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ctg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "            </ul>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "partials/swipe_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 27,  89 => 26,  86 => 25,  82 => 23,  76 => 22,  68 => 19,  65 => 18,  62 => 17,  58 => 16,  55 => 15,  53 => 14,  48 => 13,  45 => 12,  41 => 11,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"large-modal modal fade\" id=\"menuModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
    <div class=\"modal-content\">
        <div class=\"close-modal\" data-dismiss=\"modal\">
            <div class=\"lr\">
                <div class=\"rl\"></div>
            </div>
        </div>
        <div class=\"container\">
            <ul id=\"blue-mobile-menu\">
                <li><a href=\"#\">Home</a></li>
                {% for ctg in categories %}
                    {% if ctg.isVisible == \"1\" %}
                        <li><a href=\"#\">{{ ctg.name }}</a></li>
                        {% if ctg.children %}
                            <ul>
                                {% for subctg in ctg.children %}
                                    {% if subctg.isVisible == \"1\" %}
                                        <li>
                                            <a href=\"{{ path('products_list', {'id':subctg.id}) }}\">{{ subctg.name }}</a>
                                        </li>
                                    {% endif %}
                                {% endfor %}
                            </ul>
                        {% endif %}
                    {% endif %}
                {% endfor %}
            </ul>
        </div>
    </div>
</div>", "partials/swipe_menu.html.twig", "/var/www/html/anosia/templates/partials/swipe_menu.html.twig");
    }
}
