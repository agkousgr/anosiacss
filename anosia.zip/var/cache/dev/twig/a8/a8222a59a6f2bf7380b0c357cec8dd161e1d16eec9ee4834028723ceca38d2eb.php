<?php

/* partials/top_header.html.twig */
class __TwigTemplate_14924a15d55ad4c57f5c71c4bcefc3e8faf51bee263d248070194a759b9afbfb extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/top_header.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/top_header.html.twig"));

        // line 1
        echo "<div class=\"pre-header\">
    <div class=\"container\">
        <div class=\"pre-header-wrap clearfix\">
            ";
        // line 5
        echo "            ";
        // line 6
        echo "            ";
        // line 7
        echo "            ";
        // line 8
        echo "            ";
        // line 9
        echo "            ";
        // line 10
        echo "            ";
        // line 11
        echo "            ";
        // line 12
        echo "            ";
        // line 13
        echo "            ";
        // line 14
        echo "            ";
        // line 15
        echo "            ";
        // line 16
        echo "            ";
        // line 17
        echo "            ";
        // line 18
        echo "            ";
        // line 19
        echo "            ";
        // line 20
        echo "            ";
        // line 21
        echo "            ";
        // line 22
        echo "            ";
        // line 23
        echo "            ";
        // line 24
        echo "

            ";
        // line 27
        echo "            ";
        // line 28
        echo "            ";
        // line 29
        echo "            ";
        // line 30
        echo "            ";
        // line 31
        echo "            ";
        // line 32
        echo "            ";
        // line 33
        echo "            ";
        // line 34
        echo "            ";
        // line 35
        echo "            ";
        // line 36
        echo "            ";
        // line 37
        echo "            ";
        // line 38
        echo "

            <div class=\"pre-header-right\">
                <ul>
                    <li>
                        ";
        // line 43
        if (((isset($context["loggedUser"]) || array_key_exists("loggedUser", $context) ? $context["loggedUser"] : (function () { throw new Twig_Error_Runtime('Variable "loggedUser" does not exist.', 43, $this->source); })()) == null)) {
            // line 44
            echo "                            ";
            // line 45
            echo "                            ";
            // line 46
            echo "                            <a href=\"#\" class=\"account-link toggle-sidebar\" style=\"margin-top: 8px;\" title=\" Ο λογαριασμός μου\">
                                <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                            </a>
                        ";
        } else {
            // line 50
            echo "                            ";
            // line 51
            echo "                            ";
            // line 52
            echo "                            <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_account");
            echo "\" class=\"account-link\"
                               style=\"margin-top: 8px;\" title=\" Ο λογαριασμός μου\">
                                <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                            </a>
                        ";
        }
        // line 57
        echo "                    </li>
                    <li>
                        <a href=\"#\" class=\"wishlist-link\" style=\"margin-top: 10px; title=\" Wishlist\">
                        <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                        <span id=\"wishlist-total-items\" class=\"count-baloon\">100</span>
                        </a>
                    </li>
                    <li id=\"top-cart\">
                        <a data-toggle=\"collapse\" href=\"#collapseCart\" aria-expanded=\"false\"
                           aria-controls=\"collapseCart\" style=\"margin-top: 8px;\" class=\"cart-link\" title=\"Καλάθι\">
                            <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                            ";
        // line 68
        if (((isset($context["totalCartItems"]) || array_key_exists("totalCartItems", $context) ? $context["totalCartItems"] : (function () { throw new Twig_Error_Runtime('Variable "totalCartItems" does not exist.', 68, $this->source); })()) > 0)) {
            // line 69
            echo "                                ";
            $context["display"] = "inline";
            // line 70
            echo "                            ";
        } else {
            // line 71
            echo "                                ";
            $context["display"] = "none";
            // line 72
            echo "                            ";
        }
        // line 73
        echo "                            <span id=\"cart-total-items\" class=\"count-baloon\" style=\"display:";
        echo twig_escape_filter($this->env, (isset($context["display"]) || array_key_exists("display", $context) ? $context["display"] : (function () { throw new Twig_Error_Runtime('Variable "display" does not exist.', 73, $this->source); })()), "html", null, true);
        echo ";\">
                                ";
        // line 74
        echo twig_escape_filter($this->env, (isset($context["totalCartItems"]) || array_key_exists("totalCartItems", $context) ? $context["totalCartItems"] : (function () { throw new Twig_Error_Runtime('Variable "totalCartItems" does not exist.', 74, $this->source); })()), "html", null, true);
        echo "
                            </span>
                        </a>
                    </li>
                    <li>
                        <a data-toggle=\"collapse\" href=\"#collapseSearch\" aria-expanded=\"false\"
                           aria-controls=\"collapseSearch\" class=\"search-link\">
                            <span class=\"link-text\">αναζητηση</span>
                        </a>
                    </li>
                </ul>


                <div class=\"cart-dropdown collapse\" id=\"collapseCart\">
                    ";
        // line 89
        echo "                </div>

            </div>
        </div>
    </div>

    <div class=\"search-collapse collapse\" id=\"collapseSearch\">
        <div class=\"well\">
            <div class=\"container\">
                <div class=\"search-wrap\">
                    <a data-toggle=\"collapse\" href=\"#collapseSearch\" aria-expanded=\"false\"
                       aria-controls=\"collapseSearch\"
                       class=\"close-btn visible-lg visible-md visible-sm\">Search</a>
                    <div class=\"row\">
                        <div class=\"col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2\">
                            <div class=\"search\">
                                <form action=\"";
        // line 105
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_search");
        echo "\" method=\"post\">
                                    <div class=\"textbox\">
                                        <input name=\"keyword\" required class=\"form-control\" type=\"text\" placeholder=\"Αναζητήστε βάσει κωδικού, ονόματος ή μάρκας\">
                                    </div>
                                    ";
        // line 110
        echo "                                        ";
        // line 111
        echo "                                            ";
        // line 112
        echo "                                            ";
        // line 113
        echo "                                            ";
        // line 114
        echo "                                            ";
        // line 115
        echo "                                            ";
        // line 116
        echo "                                            ";
        // line 117
        echo "                                        ";
        // line 118
        echo "                                    ";
        // line 119
        echo "                                    <button type=\"submit\"><i class=\"fa fa-search\"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "partials/top_header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  222 => 119,  220 => 118,  218 => 117,  216 => 116,  214 => 115,  212 => 114,  210 => 113,  208 => 112,  206 => 111,  204 => 110,  197 => 105,  179 => 89,  162 => 74,  157 => 73,  154 => 72,  151 => 71,  148 => 70,  145 => 69,  143 => 68,  130 => 57,  121 => 52,  119 => 51,  117 => 50,  111 => 46,  109 => 45,  107 => 44,  105 => 43,  98 => 38,  96 => 37,  94 => 36,  92 => 35,  90 => 34,  88 => 33,  86 => 32,  84 => 31,  82 => 30,  80 => 29,  78 => 28,  76 => 27,  72 => 24,  70 => 23,  68 => 22,  66 => 21,  64 => 20,  62 => 19,  60 => 18,  58 => 17,  56 => 16,  54 => 15,  52 => 14,  50 => 13,  48 => 12,  46 => 11,  44 => 10,  42 => 9,  40 => 8,  38 => 7,  36 => 6,  34 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"pre-header\">
    <div class=\"container\">
        <div class=\"pre-header-wrap clearfix\">
            {#<div class=\"pre-header-left\">#}
            {#<ul>#}
            {#<li>#}
            {#<select class=\"c-select\">#}
            {#<option>USD</option>#}
            {#<option>INR</option>#}
            {#<option>GBP</option>#}
            {#<option>EURO</option>#}
            {#</select>#}
            {#</li>#}
            {#<li>#}
            {#<select class=\"c-select\">#}
            {#<option>ENG</option>#}
            {#<option>ESP</option>#}
            {#<option>RUS</option>#}
            {#<option>FR</option>#}
            {#</select>#}
            {#</li>#}
            {#</ul>#}
            {#</div>#}


            {#<div class=\"news-ticker visible-lg visible-md\">#}
            {#<div class=\"ticker\">#}
            {#<div class=\"label-back\">LATEST</div>#}
            {#<div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">#}
            {#<!-- Wrapper for slides -->#}
            {#<div class=\"carousel-inner\" role=\"listbox\">#}
            {#<div class=\"item active\">Congue admodum dissentiet</div>#}
            {#<div class=\"item\">Congue admodum dissentiet</div>#}
            {#</div>#}
            {#</div>#}
            {#</div>#}
            {#</div>#}


            <div class=\"pre-header-right\">
                <ul>
                    <li>
                        {% if loggedUser == null %}
                            {#{% set accountUrl = '#' %}#}
                            {#{% set sideClass = 'toogle-sidebar' %}#}
                            <a href=\"#\" class=\"account-link toggle-sidebar\" style=\"margin-top: 8px;\" title=\" Ο λογαριασμός μου\">
                                <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                            </a>
                        {% else %}
                            {#{% set accountUrl = 'user_account' %}#}
                            {#{% set sideClass = '' %}#}
                            <a href=\"{{ path('user_account') }}\" class=\"account-link\"
                               style=\"margin-top: 8px;\" title=\" Ο λογαριασμός μου\">
                                <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                            </a>
                        {% endif %}
                    </li>
                    <li>
                        <a href=\"#\" class=\"wishlist-link\" style=\"margin-top: 10px; title=\" Wishlist\">
                        <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                        <span id=\"wishlist-total-items\" class=\"count-baloon\">100</span>
                        </a>
                    </li>
                    <li id=\"top-cart\">
                        <a data-toggle=\"collapse\" href=\"#collapseCart\" aria-expanded=\"false\"
                           aria-controls=\"collapseCart\" style=\"margin-top: 8px;\" class=\"cart-link\" title=\"Καλάθι\">
                            <span class=\"link-text\" style=\"visibility:hidden\">.</span>
                            {% if (totalCartItems > 0) %}
                                {% set display = 'inline' %}
                            {% else %}
                                {% set display = 'none' %}
                            {% endif %}
                            <span id=\"cart-total-items\" class=\"count-baloon\" style=\"display:{{ display }};\">
                                {{ totalCartItems }}
                            </span>
                        </a>
                    </li>
                    <li>
                        <a data-toggle=\"collapse\" href=\"#collapseSearch\" aria-expanded=\"false\"
                           aria-controls=\"collapseSearch\" class=\"search-link\">
                            <span class=\"link-text\">αναζητηση</span>
                        </a>
                    </li>
                </ul>


                <div class=\"cart-dropdown collapse\" id=\"collapseCart\">
                    {#{% include 'partials/top_cart.html.twig' %}#}
                </div>

            </div>
        </div>
    </div>

    <div class=\"search-collapse collapse\" id=\"collapseSearch\">
        <div class=\"well\">
            <div class=\"container\">
                <div class=\"search-wrap\">
                    <a data-toggle=\"collapse\" href=\"#collapseSearch\" aria-expanded=\"false\"
                       aria-controls=\"collapseSearch\"
                       class=\"close-btn visible-lg visible-md visible-sm\">Search</a>
                    <div class=\"row\">
                        <div class=\"col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2\">
                            <div class=\"search\">
                                <form action=\"{{ path('product_search') }}\" method=\"post\">
                                    <div class=\"textbox\">
                                        <input name=\"keyword\" required class=\"form-control\" type=\"text\" placeholder=\"Αναζητήστε βάσει κωδικού, ονόματος ή μάρκας\">
                                    </div>
                                    {#<div class=\"option-box\">#}
                                        {#<select class=\"c-select\">#}
                                            {#<option>All</option>#}
                                            {#<option>Women</option>#}
                                            {#<option>Men</option>#}
                                            {#<option>Juniors</option>#}
                                            {#<option>Kids</option>#}
                                            {#<option>Accessories</option>#}
                                        {#</select>#}
                                    {#</div>#}
                                    <button type=\"submit\"><i class=\"fa fa-search\"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>", "partials/top_header.html.twig", "/var/www/html/anosia/templates/partials/top_header.html.twig");
    }
}
