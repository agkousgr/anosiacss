<?php
/**
 * Created by PhpStorm.
 * User: john
 * Date: 20/5/2018
 * Time: 9:08 μμ
 */

namespace App\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class UserRepository
 */
class BlogRepository extends EntityRepository
{

}