$('#confirm-addresses').on('click', function (e) {
    alert('zong');
})